package com.jobportal.entity;

public enum JobSource {
    DIRECT,
    EXTERNAL
}
