package com.jobportal.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "external_sync_logs")
public class ExternalSyncLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sync_time", nullable = false, updatable = false)
    private LocalDateTime syncTime;

    @Column(name = "provider_name", nullable = false, length = 100)
    private String providerName;

    @Column(nullable = false, length = 50)
    private String status;

    @Column(name = "jobs_added")
    private Integer jobsAdded = 0;

    @Column(name = "jobs_updated")
    private Integer jobsUpdated = 0;

    @Column(name = "execution_duration_ms")
    private Long executionDurationMs = 0L;

    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    public ExternalSyncLog() {
    }

    public ExternalSyncLog(String providerName, String status, Integer jobsAdded, Integer jobsUpdated, Long executionDurationMs, String errorMessage) {
        this.providerName = providerName;
        this.status = status;
        this.jobsAdded = jobsAdded;
        this.jobsUpdated = jobsUpdated;
        this.executionDurationMs = executionDurationMs;
        this.errorMessage = errorMessage;
    }

    @PrePersist
    protected void onCreate() {
        this.syncTime = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getSyncTime() {
        return syncTime;
    }

    public void setSyncTime(LocalDateTime syncTime) {
        this.syncTime = syncTime;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getJobsAdded() {
        return jobsAdded;
    }

    public void setJobsAdded(Integer jobsAdded) {
        this.jobsAdded = jobsAdded;
    }

    public Integer getJobsUpdated() {
        return jobsUpdated;
    }

    public void setJobsUpdated(Integer jobsUpdated) {
        this.jobsUpdated = jobsUpdated;
    }

    public Long getExecutionDurationMs() {
        return executionDurationMs;
    }

    public void setExecutionDurationMs(Long executionDurationMs) {
        this.executionDurationMs = executionDurationMs;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
