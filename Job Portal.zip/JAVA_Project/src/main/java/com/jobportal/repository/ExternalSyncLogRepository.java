package com.jobportal.repository;

import com.jobportal.entity.ExternalSyncLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ExternalSyncLogRepository extends JpaRepository<ExternalSyncLog, Long> {
    Optional<ExternalSyncLog> findTopByOrderBySyncTimeDesc();
    List<ExternalSyncLog> findAllByOrderBySyncTimeDesc();
}
