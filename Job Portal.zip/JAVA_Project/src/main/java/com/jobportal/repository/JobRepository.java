package com.jobportal.repository;

import com.jobportal.entity.Job;
import com.jobportal.entity.JobSource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface JobRepository extends JpaRepository<Job, Long> {
    List<Job> findByRecruiterId(Long recruiterId);
    List<Job> findByCompanyId(Long companyId);
    Optional<Job> findByExternalIdAndSourceName(String externalId, String sourceName);
    long countByIsActive(boolean isActive);
    long countBySource(JobSource source);
}
