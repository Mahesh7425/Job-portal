package com.jobportal.repository;

import com.jobportal.entity.Application;
import com.jobportal.entity.ApplicationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByJobSeekerId(Long jobSeekerId);
    List<Application> findByJobId(Long jobId);
    Optional<Application> findByJobIdAndJobSeekerId(Long jobId, Long jobSeekerId);
    boolean existsByJobIdAndJobSeekerId(Long jobId, Long jobSeekerId);
    long countByStatus(ApplicationStatus status);
    long countByJobRecruiterId(Long recruiterId);
    long countByJobRecruiterIdAndStatus(Long recruiterId, ApplicationStatus status);
}
