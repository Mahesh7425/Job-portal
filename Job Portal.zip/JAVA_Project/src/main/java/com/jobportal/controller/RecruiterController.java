package com.jobportal.controller;

import com.jobportal.dto.response.RecruiterProfileResponse;
import com.jobportal.service.RecruiterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/recruiter")
@PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
public class RecruiterController {

    private final RecruiterService recruiterService;

    @Autowired
    public RecruiterController(RecruiterService recruiterService) {
        this.recruiterService = recruiterService;
    }

    @GetMapping("/profile")
    public ResponseEntity<RecruiterProfileResponse> getProfile(Authentication authentication) {
        RecruiterProfileResponse profile = recruiterService.getProfileByEmail(authentication.getName());
        return ResponseEntity.ok(profile);
    }

    @PutMapping("/profile")
    public ResponseEntity<RecruiterProfileResponse> updateProfile(Authentication authentication,
                                                                 @RequestBody Map<String, Object> body) {
        String designation = (String) body.get("designation");
        Long companyId = null;
        if (body.get("companyId") != null) {
            companyId = Long.valueOf(body.get("companyId").toString());
        }

        RecruiterProfileResponse profile = recruiterService.updateProfile(authentication.getName(), designation, companyId);
        return ResponseEntity.ok(profile);
    }
}
