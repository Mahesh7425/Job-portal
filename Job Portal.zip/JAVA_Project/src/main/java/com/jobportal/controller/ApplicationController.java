package com.jobportal.controller;

import com.jobportal.dto.request.ApplicationRequest;
import com.jobportal.dto.request.ApplicationStatusUpdateRequest;
import com.jobportal.dto.response.ApiResponse;
import com.jobportal.dto.response.ApplicationResponse;
import com.jobportal.service.ApplicationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

    private final ApplicationService applicationService;

    @Autowired
    public ApplicationController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('ROLE_JOB_SEEKER', 'ROLE_ADMIN')")
    public ResponseEntity<ApplicationResponse> applyForJob(Authentication authentication,
                                                           @Valid @RequestBody ApplicationRequest request) {
        ApplicationResponse response = applicationService.applyForJob(authentication.getName(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_JOB_SEEKER', 'ROLE_ADMIN')")
    public ResponseEntity<ApiResponse> withdrawApplication(Authentication authentication,
                                                           @PathVariable Long id) {
        applicationService.withdrawApplication(authentication.getName(), id);
        return ResponseEntity.ok(new ApiResponse(true, "Application withdrawn successfully"));
    }

    @GetMapping("/my-applications")
    @PreAuthorize("hasAnyAuthority('ROLE_JOB_SEEKER', 'ROLE_ADMIN')")
    public ResponseEntity<List<ApplicationResponse>> getMyApplications(Authentication authentication) {
        return ResponseEntity.ok(applicationService.getMyApplications(authentication.getName()));
    }

    @GetMapping("/job/{jobId}")
    @PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
    public ResponseEntity<List<ApplicationResponse>> getApplicantsForJob(Authentication authentication,
                                                                         @PathVariable Long jobId) {
        return ResponseEntity.ok(applicationService.getApplicantsForJob(authentication.getName(), jobId));
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
    public ResponseEntity<ApplicationResponse> updateApplicationStatus(Authentication authentication,
                                                                       @PathVariable Long id,
                                                                       @Valid @RequestBody ApplicationStatusUpdateRequest request) {
        ApplicationResponse response = applicationService.updateApplicationStatus(authentication.getName(), id, request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApplicationResponse> getApplicationById(@PathVariable Long id) {
        return ResponseEntity.ok(applicationService.getApplicationById(id));
    }
}
