package com.jobportal.controller;

import com.jobportal.dto.response.ApiResponse;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.service.SavedJobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/saved-jobs")
@PreAuthorize("hasAnyAuthority('ROLE_JOB_SEEKER', 'ROLE_ADMIN')")
public class SavedJobController {

    private final SavedJobService savedJobService;

    @Autowired
    public SavedJobController(SavedJobService savedJobService) {
        this.savedJobService = savedJobService;
    }

    @PostMapping("/{jobId}")
    public ResponseEntity<ApiResponse> saveJob(Authentication authentication,
                                               @PathVariable Long jobId) {
        savedJobService.saveJob(authentication.getName(), jobId);
        return ResponseEntity.ok(new ApiResponse(true, "Job saved successfully"));
    }

    @DeleteMapping("/{jobId}")
    public ResponseEntity<ApiResponse> unsaveJob(Authentication authentication,
                                                 @PathVariable Long jobId) {
        savedJobService.unsaveJob(authentication.getName(), jobId);
        return ResponseEntity.ok(new ApiResponse(true, "Job removed from saved jobs"));
    }

    @GetMapping
    public ResponseEntity<List<JobResponse>> getSavedJobs(Authentication authentication) {
        return ResponseEntity.ok(savedJobService.getSavedJobs(authentication.getName()));
    }

    @GetMapping("/check/{jobId}")
    public ResponseEntity<Map<String, Boolean>> isJobSaved(Authentication authentication,
                                                           @PathVariable Long jobId) {
        boolean saved = savedJobService.isJobSaved(authentication.getName(), jobId);
        return ResponseEntity.ok(Map.of("saved", saved));
    }
}
