package com.jobportal.controller;

import com.jobportal.dto.request.JobCreateRequest;
import com.jobportal.dto.request.JobSearchFilter;
import com.jobportal.dto.response.ApiResponse;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.entity.EmploymentType;
import com.jobportal.entity.JobSource;
import com.jobportal.service.JobService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/jobs")
public class JobController {

    private final JobService jobService;

    @Autowired
    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> searchJobs(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String skill,
            @RequestParam(required = false) BigDecimal salaryMin,
            @RequestParam(required = false) Integer experience,
            @RequestParam(required = false) EmploymentType employmentType,
            @RequestParam(required = false) JobSource source,
            @RequestParam(required = false, defaultValue = "true") Boolean isActive,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "postedAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir
    ) {
        JobSearchFilter filter = new JobSearchFilter();
        filter.setKeyword(keyword);
        filter.setTitle(title);
        filter.setLocation(location);
        filter.setSkill(skill);
        filter.setSalaryMin(salaryMin);
        filter.setExperience(experience);
        filter.setEmploymentType(employmentType);
        filter.setSource(source);
        filter.setIsActive(isActive);
        filter.setPage(page);
        filter.setSize(size);
        filter.setSortBy(sortBy);
        filter.setSortDir(sortDir);

        Map<String, Object> result = jobService.searchJobs(filter);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobResponse> getJobById(@PathVariable Long id) {
        return ResponseEntity.ok(jobService.getJobById(id));
    }

    @GetMapping("/company/{companyId}")
    public ResponseEntity<List<JobResponse>> getJobsByCompany(@PathVariable Long companyId) {
        return ResponseEntity.ok(jobService.getJobsByCompany(companyId));
    }

    @GetMapping("/recruiter")
    @PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
    public ResponseEntity<List<JobResponse>> getRecruiterJobs(Authentication authentication) {
        return ResponseEntity.ok(jobService.getJobsByRecruiter(authentication.getName()));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
    public ResponseEntity<JobResponse> createJob(Authentication authentication,
                                                 @Valid @RequestBody JobCreateRequest request) {
        JobResponse created = jobService.createJob(authentication.getName(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
    public ResponseEntity<JobResponse> updateJob(Authentication authentication,
                                                 @PathVariable Long id,
                                                 @Valid @RequestBody JobCreateRequest request) {
        JobResponse updated = jobService.updateJob(authentication.getName(), id, request);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
    public ResponseEntity<ApiResponse> deleteJob(Authentication authentication,
                                                 @PathVariable Long id) {
        jobService.deleteJob(authentication.getName(), id);
        return ResponseEntity.ok(new ApiResponse(true, "Job listing deleted successfully"));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyAuthority('ROLE_RECRUITER', 'ROLE_ADMIN')")
    public ResponseEntity<JobResponse> toggleJobStatus(Authentication authentication,
                                                       @PathVariable Long id,
                                                       @RequestBody Map<String, Boolean> body) {
        boolean active = body.getOrDefault("active", true);
        JobResponse response = jobService.toggleJobStatus(authentication.getName(), id, active);
        return ResponseEntity.ok(response);
    }
}
