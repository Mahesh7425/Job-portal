package com.jobportal.controller;

import com.jobportal.entity.ExternalSyncLog;
import com.jobportal.service.ExternalJobAggregationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class ExternalJobSyncController {

    private final ExternalJobAggregationService syncService;

    @Autowired
    public ExternalJobSyncController(ExternalJobAggregationService syncService) {
        this.syncService = syncService;
    }

    @PostMapping("/sync-now")
    public ResponseEntity<ExternalSyncLog> triggerManualSync(@RequestBody(required = false) Map<String, String> body) {
        String provider = (body != null) ? body.get("provider") : null;
        ExternalSyncLog log = (provider != null) ? syncService.synchronizeExternalJobs(provider) : syncService.synchronizeExternalJobs();
        return ResponseEntity.ok(log);
    }

    @GetMapping("/sync-logs")
    public ResponseEntity<List<ExternalSyncLog>> getSyncLogs() {
        return ResponseEntity.ok(syncService.getSyncLogs());
    }
}
