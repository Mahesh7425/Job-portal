package com.jobportal.controller;

import com.jobportal.dto.request.EducationDTO;
import com.jobportal.dto.request.ExperienceDTO;
import com.jobportal.dto.request.ProfileUpdateRequest;
import com.jobportal.dto.request.SkillDTO;
import com.jobportal.dto.response.ApiResponse;
import com.jobportal.dto.response.JobSeekerProfileResponse;
import com.jobportal.service.JobSeekerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/job-seeker")
public class JobSeekerController {

    private final JobSeekerService jobSeekerService;

    @Autowired
    public JobSeekerController(JobSeekerService jobSeekerService) {
        this.jobSeekerService = jobSeekerService;
    }

    @GetMapping("/profile")
    public ResponseEntity<JobSeekerProfileResponse> getProfile(Authentication authentication) {
        JobSeekerProfileResponse profile = jobSeekerService.getProfileByEmail(authentication.getName());
        return ResponseEntity.ok(profile);
    }

    @PutMapping("/profile")
    public ResponseEntity<JobSeekerProfileResponse> updateProfile(Authentication authentication,
                                                                 @RequestBody ProfileUpdateRequest request) {
        JobSeekerProfileResponse profile = jobSeekerService.updateProfile(authentication.getName(), request);
        return ResponseEntity.ok(profile);
    }

    @PostMapping("/resume")
    public ResponseEntity<ApiResponse> uploadResume(Authentication authentication,
                                                     @RequestParam("file") MultipartFile file) {
        String resumePath = jobSeekerService.uploadResume(authentication.getName(), file);
        return ResponseEntity.ok(new ApiResponse(true, "Resume uploaded successfully: " + resumePath));
    }

    @GetMapping("/resume/{seekerId}")
    public ResponseEntity<Resource> downloadResume(@PathVariable Long seekerId) {
        Resource resource = jobSeekerService.downloadResume(seekerId);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

    @PostMapping("/skills")
    public ResponseEntity<SkillDTO> addSkill(Authentication authentication,
                                             @RequestBody Map<String, String> body) {
        String skillName = body.get("name");
        SkillDTO skillDTO = jobSeekerService.addSkill(authentication.getName(), skillName);
        return ResponseEntity.status(HttpStatus.CREATED).body(skillDTO);
    }

    @DeleteMapping("/skills/{skillId}")
    public ResponseEntity<ApiResponse> removeSkill(Authentication authentication,
                                                   @PathVariable Long skillId) {
        jobSeekerService.removeSkill(authentication.getName(), skillId);
        return ResponseEntity.ok(new ApiResponse(true, "Skill removed successfully"));
    }

    @PostMapping("/education")
    public ResponseEntity<EducationDTO> addEducation(Authentication authentication,
                                                     @Valid @RequestBody EducationDTO educationDTO) {
        EducationDTO created = jobSeekerService.addEducation(authentication.getName(), educationDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/education/{id}")
    public ResponseEntity<EducationDTO> updateEducation(Authentication authentication,
                                                        @PathVariable Long id,
                                                        @Valid @RequestBody EducationDTO educationDTO) {
        EducationDTO updated = jobSeekerService.updateEducation(authentication.getName(), id, educationDTO);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/education/{id}")
    public ResponseEntity<ApiResponse> deleteEducation(Authentication authentication,
                                                      @PathVariable Long id) {
        jobSeekerService.deleteEducation(authentication.getName(), id);
        return ResponseEntity.ok(new ApiResponse(true, "Education entry deleted successfully"));
    }

    @PostMapping("/experience")
    public ResponseEntity<ExperienceDTO> addExperience(Authentication authentication,
                                                       @Valid @RequestBody ExperienceDTO experienceDTO) {
        ExperienceDTO created = jobSeekerService.addExperience(authentication.getName(), experienceDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/experience/{id}")
    public ResponseEntity<ExperienceDTO> updateExperience(Authentication authentication,
                                                          @PathVariable Long id,
                                                          @Valid @RequestBody ExperienceDTO experienceDTO) {
        ExperienceDTO updated = jobSeekerService.updateExperience(authentication.getName(), id, experienceDTO);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/experience/{id}")
    public ResponseEntity<ApiResponse> deleteExperience(Authentication authentication,
                                                        @PathVariable Long id) {
        jobSeekerService.deleteExperience(authentication.getName(), id);
        return ResponseEntity.ok(new ApiResponse(true, "Experience entry deleted successfully"));
    }
}
