package com.jobportal.scheduler;

import com.jobportal.entity.ExternalSyncLog;
import com.jobportal.service.ExternalJobAggregationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ExternalJobSyncScheduler {

    private static final Logger logger = LoggerFactory.getLogger(ExternalJobSyncScheduler.class);
    private final ExternalJobAggregationService syncService;

    @Autowired
    public ExternalJobSyncScheduler(ExternalJobAggregationService syncService) {
        this.syncService = syncService;
    }

    @Scheduled(cron = "${job.sync.cron:0 */30 * * * *}")
    public void runScheduledJobSync() {
        logger.info("Starting automated external job synchronization task...");
        ExternalSyncLog log = syncService.synchronizeExternalJobs();
        logger.info("Automated job sync finished. Status: {}, Added: {}, Updated: {}, Duration: {}ms",
                log.getStatus(), log.getJobsAdded(), log.getJobsUpdated(), log.getExecutionDurationMs());
    }
}
