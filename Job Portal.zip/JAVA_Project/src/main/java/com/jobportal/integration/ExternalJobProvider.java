package com.jobportal.integration;

import java.util.List;

public interface ExternalJobProvider {
    String getProviderName();
    List<ExternalJobDTO> fetchJobs();
}
