package com.jobportal.integration.impl;

import com.jobportal.entity.EmploymentType;
import com.jobportal.integration.ExternalJobDTO;
import com.jobportal.integration.ExternalJobProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component("remoteokJobProvider")
public class RemoteOkJobProviderImpl implements ExternalJobProvider {

    private final RestTemplate restTemplate;
    private static final String REMOTEOK_API_URL = "https://remoteok.com/api";

    @Autowired
    public RemoteOkJobProviderImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public String getProviderName() {
        return "RemoteOK Public API";
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ExternalJobDTO> fetchJobs() {
        List<ExternalJobDTO> result = new ArrayList<>();
        try {
            ResponseEntity<List> response = restTemplate.getForEntity(REMOTEOK_API_URL, List.class);
            if (response.getBody() != null && !response.getBody().isEmpty()) {
                List<Map<String, Object>> items = (List<Map<String, Object>>) response.getBody();
                
                // First element in RemoteOK JSON is metadata, skip index 0
                for (int i = 1; i < Math.min(items.size(), 25); i++) {
                    Map<String, Object> item = items.get(i);
                    if (item.get("id") == null || item.get("position") == null) {
                        continue;
                    }

                    String id = String.valueOf(item.get("id"));
                    String title = String.valueOf(item.get("position"));
                    String company = item.get("company") != null ? String.valueOf(item.get("company")) : "Remote Company";
                    String url = item.get("url") != null ? String.valueOf(item.get("url")) : "https://remoteok.com";
                    String location = item.get("location") != null && !String.valueOf(item.get("location")).isEmpty() 
                            ? String.valueOf(item.get("location")) : "Remote";
                    String description = item.get("description") != null ? String.valueOf(item.get("description")) : title;

                    BigDecimal salaryMin = null;
                    BigDecimal salaryMax = null;
                    if (item.get("salary_min") != null) {
                        try {
                            salaryMin = new BigDecimal(String.valueOf(item.get("salary_min")));
                        } catch (Exception ignored) {}
                    }
                    if (item.get("salary_max") != null) {
                        try {
                            salaryMax = new BigDecimal(String.valueOf(item.get("salary_max")));
                        } catch (Exception ignored) {}
                    }

                    LocalDateTime postedAt = LocalDateTime.now();
                    if (item.get("epoch") != null) {
                        try {
                            long epoch = Long.parseLong(String.valueOf(item.get("epoch")));
                            postedAt = LocalDateTime.ofInstant(Instant.ofEpochSecond(epoch), ZoneId.systemDefault());
                        } catch (Exception ignored) {}
                    }

                    ExternalJobDTO dto = new ExternalJobDTO(
                            "rok-" + id,
                            getProviderName(),
                            company,
                            url,
                            title,
                            description,
                            location,
                            salaryMin,
                            salaryMax,
                            EmploymentType.REMOTE,
                            2,
                            postedAt
                    );
                    result.add(dto);
                }
            }
        } catch (Exception ex) {
            System.err.println("Error fetching external jobs from RemoteOK: " + ex.getMessage());
        }
        return result;
    }
}
