package com.jobportal.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ExternalJobProviderFactory {

    @Value("${job.sync.provider:mock}")
    private String configuredProvider;

    private final Map<String, ExternalJobProvider> providers;

    @Autowired
    public ExternalJobProviderFactory(Map<String, ExternalJobProvider> providers) {
        this.providers = providers;
    }

    public ExternalJobProvider getProvider() {
        if ("remoteok".equalsIgnoreCase(configuredProvider)) {
            return providers.get("remoteokJobProvider");
        }
        return providers.get("mockJobProvider");
    }

    public ExternalJobProvider getProvider(String providerName) {
        if ("remoteok".equalsIgnoreCase(providerName)) {
            return providers.get("remoteokJobProvider");
        }
        return providers.get("mockJobProvider");
    }
}
