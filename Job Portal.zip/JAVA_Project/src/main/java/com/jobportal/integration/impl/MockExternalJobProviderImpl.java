package com.jobportal.integration.impl;

import com.jobportal.entity.EmploymentType;
import com.jobportal.integration.ExternalJobDTO;
import com.jobportal.integration.ExternalJobProvider;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Component("mockJobProvider")
public class MockExternalJobProviderImpl implements ExternalJobProvider {

    @Override
    public String getProviderName() {
        return "Mock External Feed";
    }

    @Override
    public List<ExternalJobDTO> fetchJobs() {
        List<ExternalJobDTO> jobs = new ArrayList<>();

        jobs.add(new ExternalJobDTO(
                "mock-ext-101",
                getProviderName(),
                "Apex Cloud Systems",
                "https://apexcloud.example.com/careers/java-lead",
                "Lead Java Microservices Architect",
                "Designing scalable distributed microservices with Java 17, Spring Boot, Spring Data JPA, and Kafka. Remote friendly position.",
                "Remote / Chicago, IL",
                new BigDecimal("130000.00"),
                new BigDecimal("165000.00"),
                EmploymentType.REMOTE,
                5,
                LocalDateTime.now().minusHours(4)
        ));

        jobs.add(new ExternalJobDTO(
                "mock-ext-102",
                getProviderName(),
                "Nexus FinTech Solutions",
                "https://nexusfintech.example.com/jobs/fullstack-js-java",
                "Full Stack Engineer (Java + React/Vanilla JS)",
                "Join our high frequency trading backend team. Modern web frontend integration with robust Spring Security backend REST APIs.",
                "New York, NY",
                new BigDecimal("115000.00"),
                new BigDecimal("145000.00"),
                EmploymentType.FULL_TIME,
                3,
                LocalDateTime.now().minusHours(12)
        ));

        jobs.add(new ExternalJobDTO(
                "mock-ext-103",
                getProviderName(),
                "DataScale AI",
                "https://datascale.example.com/careers/data-engineer",
                "Backend Data Platform Developer",
                "High throughput data pipeline developer using Java JDBC, MySQL, and Python data processing tools.",
                "Austin, TX",
                new BigDecimal("105000.00"),
                new BigDecimal("135000.00"),
                EmploymentType.FULL_TIME,
                2,
                LocalDateTime.now().minusDays(1)
        ));

        jobs.add(new ExternalJobDTO(
                "mock-ext-104",
                getProviderName(),
                "Global CyberSec Corp",
                "https://cybersec.example.com/jobs/devsecops",
                "Spring Security & CyberSec Engineer",
                "Securing enterprise Spring Boot applications, OAuth2/JWT token flows, and vulnerability assessment.",
                "Remote / Washington, DC",
                new BigDecimal("120000.00"),
                new BigDecimal("150000.00"),
                EmploymentType.CONTRACT,
                4,
                LocalDateTime.now().minusDays(2)
        ));

        jobs.add(new ExternalJobDTO(
                "mock-ext-105",
                getProviderName(),
                "Vanguard Mobile Apps",
                "https://vanguardmobile.example.com/jobs/junior-java",
                "Junior Backend Java Developer",
                "Great entry level position for MCA/CS graduates! Build REST endpoints with Spring MVC and MySQL.",
                "Seattle, WA",
                new BigDecimal("75000.00"),
                new BigDecimal("95000.00"),
                EmploymentType.FULL_TIME,
                1,
                LocalDateTime.now().minusHours(8)
        ));

        return jobs;
    }
}
