package com.jobportal.dao;

import com.jobportal.entity.User;
import java.util.List;
import java.util.Optional;

public interface UserJdbcDao {
    Optional<User> findByEmailWithJdbc(String email);
    boolean verifyUserCredentialsWithJdbc(String email, String rawPassword);
    List<User> findAllActiveUsersWithJdbc();
    int countTotalUsersWithJdbc();
}
