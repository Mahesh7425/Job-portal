package com.jobportal.dao;

import com.jobportal.dto.request.JobSearchFilter;
import com.jobportal.dto.response.JobResponse;

import java.util.List;

public interface JobJdbcDao {
    List<JobResponse> searchJobsWithJdbc(JobSearchFilter filter);
    int countSearchJobsWithJdbc(JobSearchFilter filter);
}
