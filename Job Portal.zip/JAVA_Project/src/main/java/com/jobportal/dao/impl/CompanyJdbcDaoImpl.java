package com.jobportal.dao.impl;

import com.jobportal.dao.CompanyJdbcDao;
import com.jobportal.entity.Company;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class CompanyJdbcDaoImpl implements CompanyJdbcDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public CompanyJdbcDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Company> companyRowMapper = new RowMapper<Company>() {
        @Override
        public Company mapRow(ResultSet rs, int rowNum) throws SQLException {
            Company company = new Company();
            company.setId(rs.getLong("id"));
            company.setName(rs.getString("name"));
            company.setDescription(rs.getString("description"));
            company.setWebsite(rs.getString("website"));
            company.setLocation(rs.getString("location"));
            company.setLogoUrl(rs.getString("logo_url"));
            company.setIndustry(rs.getString("industry"));
            if (rs.getTimestamp("created_at") != null) {
                company.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
            }
            return company;
        }
    };

    @Override
    public Optional<Company> findByIdWithJdbc(Long id) {
        String sql = "SELECT * FROM companies WHERE id = ?";
        List<Company> companies = jdbcTemplate.query(sql, companyRowMapper, id);
        return companies.stream().findFirst();
    }

    @Override
    public List<Company> findAllWithJdbc() {
        String sql = "SELECT * FROM companies ORDER BY name ASC";
        return jdbcTemplate.query(sql, companyRowMapper);
    }

    @Override
    public int countTotalCompaniesWithJdbc() {
        String sql = "SELECT COUNT(*) FROM companies";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class);
        return count != null ? count : 0;
    }
}
