package com.jobportal.dao.impl;

import com.jobportal.dao.JobJdbcDao;
import com.jobportal.dto.request.JobSearchFilter;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.entity.EmploymentType;
import com.jobportal.entity.JobSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class JobJdbcDaoImpl implements JobJdbcDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public JobJdbcDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<JobResponse> jobRowMapper = new RowMapper<JobResponse>() {
        @Override
        public JobResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
            JobResponse job = new JobResponse();
            job.setId(rs.getLong("id"));
            job.setTitle(rs.getString("title"));
            job.setDescription(rs.getString("description"));
            job.setLocation(rs.getString("location"));
            job.setSalaryMin(rs.getBigDecimal("salary_min"));
            job.setSalaryMax(rs.getBigDecimal("salary_max"));
            job.setExperienceRequired(rs.getInt("experience_required"));
            job.setEmploymentType(EmploymentType.valueOf(rs.getString("employment_type")));
            job.setActive(rs.getBoolean("is_active"));
            job.setSource(JobSource.valueOf(rs.getString("source")));
            job.setSourceName(rs.getString("source_name"));
            job.setExternalUrl(rs.getString("external_url"));
            job.setExternalId(rs.getString("external_id"));
            job.setCompanyNameExt(rs.getString("company_name_ext"));
            
            long companyId = rs.getLong("company_id");
            if (!rs.wasNull()) {
                job.setCompanyId(companyId);
                job.setCompanyName(rs.getString("company_name"));
                job.setCompanyLogoUrl(rs.getString("logo_url"));
            }

            long recruiterId = rs.getLong("recruiter_id");
            if (!rs.wasNull()) {
                job.setRecruiterId(recruiterId);
            }

            if (rs.getTimestamp("posted_at") != null) {
                job.setPostedAt(rs.getTimestamp("posted_at").toLocalDateTime());
            }

            return job;
        }
    };

    @Override
    public List<JobResponse> searchJobsWithJdbc(JobSearchFilter filter) {
        StringBuilder sql = new StringBuilder(
                "SELECT j.*, c.name AS company_name, c.logo_url FROM jobs j " +
                "LEFT JOIN companies c ON j.company_id = c.id WHERE 1=1 "
        );
        List<Object> params = new ArrayList<>();

        buildWhereClause(filter, sql, params);

        sql.append(" ORDER BY j.posted_at DESC ");
        sql.append(" LIMIT ? OFFSET ? ");

        int offset = filter.getPage() * filter.getSize();
        params.add(filter.getSize());
        params.add(offset);

        return jdbcTemplate.query(sql.toString(), jobRowMapper, params.toArray());
    }

    @Override
    public int countSearchJobsWithJdbc(JobSearchFilter filter) {
        StringBuilder sql = new StringBuilder(
                "SELECT COUNT(*) FROM jobs j " +
                "LEFT JOIN companies c ON j.company_id = c.id WHERE 1=1 "
        );
        List<Object> params = new ArrayList<>();

        buildWhereClause(filter, sql, params);

        Integer count = jdbcTemplate.queryForObject(sql.toString(), Integer.class, params.toArray());
        return count != null ? count : 0;
    }

    private void buildWhereClause(JobSearchFilter filter, StringBuilder sql, List<Object> params) {
        if (filter.getIsActive() != null) {
            sql.append(" AND j.is_active = ? ");
            params.add(filter.getIsActive());
        }

        if (filter.getKeyword() != null && !filter.getKeyword().trim().isEmpty()) {
            String kw = "%" + filter.getKeyword().trim() + "%";
            sql.append(" AND (j.title LIKE ? OR j.description LIKE ? OR j.location LIKE ? OR c.name LIKE ? OR j.company_name_ext LIKE ?) ");
            params.add(kw);
            params.add(kw);
            params.add(kw);
            params.add(kw);
            params.add(kw);
        }

        if (filter.getTitle() != null && !filter.getTitle().trim().isEmpty()) {
            sql.append(" AND j.title LIKE ? ");
            params.add("%" + filter.getTitle().trim() + "%");
        }

        if (filter.getLocation() != null && !filter.getLocation().trim().isEmpty()) {
            sql.append(" AND j.location LIKE ? ");
            params.add("%" + filter.getLocation().trim() + "%");
        }

        if (filter.getSalaryMin() != null) {
            sql.append(" AND j.salary_max >= ? ");
            params.add(filter.getSalaryMin());
        }

        if (filter.getExperience() != null) {
            sql.append(" AND j.experience_required <= ? ");
            params.add(filter.getExperience());
        }

        if (filter.getEmploymentType() != null) {
            sql.append(" AND j.employment_type = ? ");
            params.add(filter.getEmploymentType().name());
        }

        if (filter.getSource() != null) {
            sql.append(" AND j.source = ? ");
            params.add(filter.getSource().name());
        }
    }
}
