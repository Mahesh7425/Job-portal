package com.jobportal.dao.impl;

import com.jobportal.dao.ApplicationJdbcDao;
import com.jobportal.entity.ApplicationStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ApplicationJdbcDaoImpl implements ApplicationJdbcDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public ApplicationJdbcDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public boolean updateApplicationStatusWithJdbc(Long applicationId, ApplicationStatus status) {
        String sql = "UPDATE applications SET status = ?, updated_at = NOW() WHERE id = ?";
        int rows = jdbcTemplate.update(sql, status.name(), applicationId);
        return rows > 0;
    }

    @Override
    public int countTotalApplicationsWithJdbc() {
        String sql = "SELECT COUNT(*) FROM applications";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class);
        return count != null ? count : 0;
    }

    @Override
    public int countApplicationsByStatusWithJdbc(ApplicationStatus status) {
        String sql = "SELECT COUNT(*) FROM applications WHERE status = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, status.name());
        return count != null ? count : 0;
    }
}
