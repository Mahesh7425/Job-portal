package com.jobportal.dao.impl;

import com.jobportal.dao.UserJdbcDao;
import com.jobportal.entity.Role;
import com.jobportal.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public class UserJdbcDaoImpl implements UserJdbcDao {

    private final JdbcTemplate jdbcTemplate;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserJdbcDaoImpl(JdbcTemplate jdbcTemplate, PasswordEncoder passwordEncoder) {
        this.jdbcTemplate = jdbcTemplate;
        this.passwordEncoder = passwordEncoder;
    }

    private final RowMapper<User> userRowMapper = new RowMapper<User>() {
        @Override
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            User user = new User();
            user.setId(rs.getLong("id"));
            user.setEmail(rs.getString("email"));
            user.setPassword(rs.getString("password"));
            user.setFullName(rs.getString("full_name"));
            user.setPhone(rs.getString("phone"));
            user.setRole(Role.valueOf(rs.getString("role")));
            user.setActive(rs.getBoolean("is_active"));
            
            if (rs.getTimestamp("created_at") != null) {
                user.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
            }
            if (rs.getTimestamp("updated_at") != null) {
                user.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());
            }
            return user;
        }
    };

    @Override
    public Optional<User> findByEmailWithJdbc(String email) {
        String sql = "SELECT * FROM users WHERE email = ? AND is_active = true";
        List<User> users = jdbcTemplate.query(sql, userRowMapper, email);
        return users.stream().findFirst();
    }

    @Override
    public boolean verifyUserCredentialsWithJdbc(String email, String rawPassword) {
        String sql = "SELECT password FROM users WHERE email = ? AND is_active = true";
        List<String> passwords = jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("password"), email);
        if (passwords.isEmpty()) {
            return false;
        }
        return passwordEncoder.matches(rawPassword, passwords.get(0));
    }

    @Override
    public List<User> findAllActiveUsersWithJdbc() {
        String sql = "SELECT * FROM users WHERE is_active = true ORDER BY id DESC";
        return jdbcTemplate.query(sql, userRowMapper);
    }

    @Override
    public int countTotalUsersWithJdbc() {
        String sql = "SELECT COUNT(*) FROM users";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class);
        return count != null ? count : 0;
    }
}
