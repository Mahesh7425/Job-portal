package com.jobportal.dao;

import com.jobportal.entity.Company;
import java.util.List;
import java.util.Optional;

public interface CompanyJdbcDao {
    Optional<Company> findByIdWithJdbc(Long id);
    List<Company> findAllWithJdbc();
    int countTotalCompaniesWithJdbc();
}
