package com.jobportal.dao;

import com.jobportal.entity.ApplicationStatus;

public interface ApplicationJdbcDao {
    boolean updateApplicationStatusWithJdbc(Long applicationId, ApplicationStatus status);
    int countTotalApplicationsWithJdbc();
    int countApplicationsByStatusWithJdbc(ApplicationStatus status);
}
