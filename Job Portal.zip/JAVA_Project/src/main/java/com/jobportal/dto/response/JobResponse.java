package com.jobportal.dto.response;

import com.jobportal.dto.request.SkillDTO;
import com.jobportal.entity.EmploymentType;
import com.jobportal.entity.JobSource;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class JobResponse {
    private Long id;
    private Long recruiterId;
    private Long companyId;
    private String companyName;
    private String companyLogoUrl;
    private String title;
    private String description;
    private String location;
    private BigDecimal salaryMin;
    private BigDecimal salaryMax;
    private Integer experienceRequired;
    private EmploymentType employmentType;
    private boolean isActive;
    private JobSource source;
    private String sourceName;
    private String externalUrl;
    private String externalId;
    private String companyNameExt;
    private LocalDateTime postedAt;
    private List<SkillDTO> requiredSkills;

    public JobResponse() {
    }

    public JobResponse(Long id, Long recruiterId, Long companyId, String companyName, String companyLogoUrl, String title, String description, String location, BigDecimal salaryMin, BigDecimal salaryMax, Integer experienceRequired, EmploymentType employmentType, boolean isActive, JobSource source, String sourceName, String externalUrl, String externalId, String companyNameExt, LocalDateTime postedAt, List<SkillDTO> requiredSkills) {
        this.id = id;
        this.recruiterId = recruiterId;
        this.companyId = companyId;
        this.companyName = companyName;
        this.companyLogoUrl = companyLogoUrl;
        this.title = title;
        this.description = description;
        this.location = location;
        this.salaryMin = salaryMin;
        this.salaryMax = salaryMax;
        this.experienceRequired = experienceRequired;
        this.employmentType = employmentType;
        this.isActive = isActive;
        this.source = source;
        this.sourceName = sourceName;
        this.externalUrl = externalUrl;
        this.externalId = externalId;
        this.companyNameExt = companyNameExt;
        this.postedAt = postedAt;
        this.requiredSkills = requiredSkills;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRecruiterId() {
        return recruiterId;
    }

    public void setRecruiterId(Long recruiterId) {
        this.recruiterId = recruiterId;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName != null ? companyName : companyNameExt;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyLogoUrl() {
        return companyLogoUrl;
    }

    public void setCompanyLogoUrl(String companyLogoUrl) {
        this.companyLogoUrl = companyLogoUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public BigDecimal getSalaryMin() {
        return salaryMin;
    }

    public void setSalaryMin(BigDecimal salaryMin) {
        this.salaryMin = salaryMin;
    }

    public BigDecimal getSalaryMax() {
        return salaryMax;
    }

    public void setSalaryMax(BigDecimal salaryMax) {
        this.salaryMax = salaryMax;
    }

    public Integer getExperienceRequired() {
        return experienceRequired;
    }

    public void setExperienceRequired(Integer experienceRequired) {
        this.experienceRequired = experienceRequired;
    }

    public EmploymentType getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(EmploymentType employmentType) {
        this.employmentType = employmentType;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public JobSource getSource() {
        return source;
    }

    public void setSource(JobSource source) {
        this.source = source;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getExternalUrl() {
        return externalUrl;
    }

    public void setExternalUrl(String externalUrl) {
        this.externalUrl = externalUrl;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getCompanyNameExt() {
        return companyNameExt;
    }

    public void setCompanyNameExt(String companyNameExt) {
        this.companyNameExt = companyNameExt;
    }

    public LocalDateTime getPostedAt() {
        return postedAt;
    }

    public void setPostedAt(LocalDateTime postedAt) {
        this.postedAt = postedAt;
    }

    public List<SkillDTO> getRequiredSkills() {
        return requiredSkills;
    }

    public void setRequiredSkills(List<SkillDTO> requiredSkills) {
        this.requiredSkills = requiredSkills;
    }
}
