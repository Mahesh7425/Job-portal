package com.jobportal.dto.request;

import java.math.BigDecimal;

public class ProfileUpdateRequest {
    private String fullName;
    private String phone;
    private String title;
    private String bio;
    private Integer experienceYears;
    private BigDecimal expectedSalary;
    private String location;

    public ProfileUpdateRequest() {
    }

    public ProfileUpdateRequest(String fullName, String phone, String title, String bio, Integer experienceYears, BigDecimal expectedSalary, String location) {
        this.fullName = fullName;
        this.phone = phone;
        this.title = title;
        this.bio = bio;
        this.experienceYears = experienceYears;
        this.expectedSalary = expectedSalary;
        this.location = location;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public Integer getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(Integer experienceYears) {
        this.experienceYears = experienceYears;
    }

    public BigDecimal getExpectedSalary() {
        return expectedSalary;
    }

    public void setExpectedSalary(BigDecimal expectedSalary) {
        this.expectedSalary = expectedSalary;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
