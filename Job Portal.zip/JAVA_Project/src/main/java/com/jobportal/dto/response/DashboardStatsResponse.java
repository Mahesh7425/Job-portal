package com.jobportal.dto.response;

import java.time.LocalDateTime;

public class DashboardStatsResponse {
    private long totalUsers;
    private long totalJobSeekers;
    private long totalRecruiters;
    private long totalCompanies;
    private long totalJobs;
    private long activeJobs;
    private long totalApplications;
    private long shortlistedCandidates;
    private long selectedCandidates;
    private LocalDateTime lastSyncTime;
    private String lastSyncStatus;

    public DashboardStatsResponse() {
    }

    public DashboardStatsResponse(long totalUsers, long totalJobSeekers, long totalRecruiters, long totalCompanies, long totalJobs, long activeJobs, long totalApplications, long shortlistedCandidates, long selectedCandidates, LocalDateTime lastSyncTime, String lastSyncStatus) {
        this.totalUsers = totalUsers;
        this.totalJobSeekers = totalJobSeekers;
        this.totalRecruiters = totalRecruiters;
        this.totalCompanies = totalCompanies;
        this.totalJobs = totalJobs;
        this.activeJobs = activeJobs;
        this.totalApplications = totalApplications;
        this.shortlistedCandidates = shortlistedCandidates;
        this.selectedCandidates = selectedCandidates;
        this.lastSyncTime = lastSyncTime;
        this.lastSyncStatus = lastSyncStatus;
    }

    public long getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(long totalUsers) {
        this.totalUsers = totalUsers;
    }

    public long getTotalJobSeekers() {
        return totalJobSeekers;
    }

    public void setTotalJobSeekers(long totalJobSeekers) {
        this.totalJobSeekers = totalJobSeekers;
    }

    public long getTotalRecruiters() {
        return totalRecruiters;
    }

    public void setTotalRecruiters(long totalRecruiters) {
        this.totalRecruiters = totalRecruiters;
    }

    public long getTotalCompanies() {
        return totalCompanies;
    }

    public void setTotalCompanies(long totalCompanies) {
        this.totalCompanies = totalCompanies;
    }

    public long getTotalJobs() {
        return totalJobs;
    }

    public void setTotalJobs(long totalJobs) {
        this.totalJobs = totalJobs;
    }

    public long getActiveJobs() {
        return activeJobs;
    }

    public void setActiveJobs(long activeJobs) {
        this.activeJobs = activeJobs;
    }

    public long getTotalApplications() {
        return totalApplications;
    }

    public void setTotalApplications(long totalApplications) {
        this.totalApplications = totalApplications;
    }

    public long getShortlistedCandidates() {
        return shortlistedCandidates;
    }

    public void setShortlistedCandidates(long shortlistedCandidates) {
        this.shortlistedCandidates = shortlistedCandidates;
    }

    public long getSelectedCandidates() {
        return selectedCandidates;
    }

    public void setSelectedCandidates(long selectedCandidates) {
        this.selectedCandidates = selectedCandidates;
    }

    public LocalDateTime getLastSyncTime() {
        return lastSyncTime;
    }

    public void setLastSyncTime(LocalDateTime lastSyncTime) {
        this.lastSyncTime = lastSyncTime;
    }

    public String getLastSyncStatus() {
        return lastSyncStatus;
    }

    public void setLastSyncStatus(String lastSyncStatus) {
        this.lastSyncStatus = lastSyncStatus;
    }
}
