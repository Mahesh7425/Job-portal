package com.jobportal.dto.response;

import com.jobportal.dto.request.EducationDTO;
import com.jobportal.dto.request.ExperienceDTO;
import com.jobportal.dto.request.SkillDTO;

import java.math.BigDecimal;
import java.util.List;

public class JobSeekerProfileResponse {
    private Long id;
    private Long userId;
    private String email;
    private String fullName;
    private String phone;
    private String title;
    private String bio;
    private String resumeUrl;
    private Integer experienceYears;
    private BigDecimal expectedSalary;
    private String location;
    private List<SkillDTO> skills;
    private List<EducationDTO> educationList;
    private List<ExperienceDTO> experienceList;

    public JobSeekerProfileResponse() {
    }

    public JobSeekerProfileResponse(Long id, Long userId, String email, String fullName, String phone, String title, String bio, String resumeUrl, Integer experienceYears, BigDecimal expectedSalary, String location, List<SkillDTO> skills, List<EducationDTO> educationList, List<ExperienceDTO> experienceList) {
        this.id = id;
        this.userId = userId;
        this.email = email;
        this.fullName = fullName;
        this.phone = phone;
        this.title = title;
        this.bio = bio;
        this.resumeUrl = resumeUrl;
        this.experienceYears = experienceYears;
        this.expectedSalary = expectedSalary;
        this.location = location;
        this.skills = skills;
        this.educationList = educationList;
        this.experienceList = experienceList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getResumeUrl() {
        return resumeUrl;
    }

    public void setResumeUrl(String resumeUrl) {
        this.resumeUrl = resumeUrl;
    }

    public Integer getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(Integer experienceYears) {
        this.experienceYears = experienceYears;
    }

    public BigDecimal getExpectedSalary() {
        return expectedSalary;
    }

    public void setExpectedSalary(BigDecimal expectedSalary) {
        this.expectedSalary = expectedSalary;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<SkillDTO> getSkills() {
        return skills;
    }

    public void setSkills(List<SkillDTO> skills) {
        this.skills = skills;
    }

    public List<EducationDTO> getEducationList() {
        return educationList;
    }

    public void setEducationList(List<EducationDTO> educationList) {
        this.educationList = educationList;
    }

    public List<ExperienceDTO> getExperienceList() {
        return experienceList;
    }

    public void setExperienceList(List<ExperienceDTO> experienceList) {
        this.experienceList = experienceList;
    }
}
