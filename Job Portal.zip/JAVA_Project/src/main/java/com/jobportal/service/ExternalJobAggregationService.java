package com.jobportal.service;

import com.jobportal.entity.ExternalSyncLog;
import java.util.List;

public interface ExternalJobAggregationService {
    ExternalSyncLog synchronizeExternalJobs();
    ExternalSyncLog synchronizeExternalJobs(String providerOverride);
    List<ExternalSyncLog> getSyncLogs();
}
