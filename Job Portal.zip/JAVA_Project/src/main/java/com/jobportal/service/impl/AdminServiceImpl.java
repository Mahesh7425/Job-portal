package com.jobportal.service.impl;

import com.jobportal.dto.request.RegisterRequest;
import com.jobportal.dto.response.DashboardStatsResponse;
import com.jobportal.dto.response.UserResponse;
import com.jobportal.entity.*;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.*;
import com.jobportal.service.AdminService;
import com.jobportal.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final JobRepository jobRepository;
    private final ApplicationRepository applicationRepository;
    private final ExternalSyncLogRepository syncLogRepository;
    private final AuthService authService;

    @Autowired
    public AdminServiceImpl(UserRepository userRepository,
                            CompanyRepository companyRepository,
                            JobRepository jobRepository,
                            ApplicationRepository applicationRepository,
                            ExternalSyncLogRepository syncLogRepository,
                            AuthService authService) {
        this.userRepository = userRepository;
        this.companyRepository = companyRepository;
        this.jobRepository = jobRepository;
        this.applicationRepository = applicationRepository;
        this.syncLogRepository = syncLogRepository;
        this.authService = authService;
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardStatsResponse getDashboardStats() {
        long totalUsers = userRepository.count();
        long totalJobSeekers = userRepository.countByRole(Role.ROLE_JOB_SEEKER);
        long totalRecruiters = userRepository.countByRole(Role.ROLE_RECRUITER);
        long totalCompanies = companyRepository.count();
        long totalJobs = jobRepository.count();
        long activeJobs = jobRepository.countByIsActive(true);
        long totalApplications = applicationRepository.count();
        long shortlisted = applicationRepository.countByStatus(ApplicationStatus.SHORTLISTED);
        long selected = applicationRepository.countByStatus(ApplicationStatus.SELECTED);

        Optional<ExternalSyncLog> latestSync = syncLogRepository.findTopByOrderBySyncTimeDesc();
        LocalDateTime lastSyncTime = latestSync.map(ExternalSyncLog::getSyncTime).orElse(null);
        String lastSyncStatus = latestSync.map(ExternalSyncLog::getStatus).orElse("NEVER_RUN");

        return new DashboardStatsResponse(
                totalUsers,
                totalJobSeekers,
                totalRecruiters,
                totalCompanies,
                totalJobs,
                activeJobs,
                totalApplications,
                shortlisted,
                selected,
                lastSyncTime,
                lastSyncStatus
        );
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream()
                .map(this::mapToUserResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public UserResponse updateUserStatus(Long userId, boolean active) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        user.setActive(active);
        User saved = userRepository.save(user);
        return mapToUserResponse(saved);
    }

    @Override
    @Transactional
    public void deleteUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        userRepository.delete(user);
    }

    @Override
    @Transactional
    public UserResponse createUser(RegisterRequest request) {
        return authService.register(request);
    }

    private UserResponse mapToUserResponse(User user) {
        return new UserResponse(
                user.getId(),
                user.getEmail(),
                user.getFullName(),
                user.getPhone(),
                user.getRole(),
                user.isActive(),
                user.getCreatedAt()
        );
    }
}
