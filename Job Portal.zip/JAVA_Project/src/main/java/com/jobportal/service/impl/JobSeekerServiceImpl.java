package com.jobportal.service.impl;

import com.jobportal.dto.request.EducationDTO;
import com.jobportal.dto.request.ExperienceDTO;
import com.jobportal.dto.request.ProfileUpdateRequest;
import com.jobportal.dto.request.SkillDTO;
import com.jobportal.dto.response.JobSeekerProfileResponse;
import com.jobportal.entity.*;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.exception.UnauthorizedAccessException;
import com.jobportal.repository.*;
import com.jobportal.service.JobSeekerService;
import com.jobportal.service.ResumeStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class JobSeekerServiceImpl implements JobSeekerService {

    private final UserRepository userRepository;
    private final JobSeekerRepository jobSeekerRepository;
    private final SkillRepository skillRepository;
    private final EducationRepository educationRepository;
    private final ExperienceRepository experienceRepository;
    private final ResumeStorageService resumeStorageService;

    @Autowired
    public JobSeekerServiceImpl(UserRepository userRepository,
                                JobSeekerRepository jobSeekerRepository,
                                SkillRepository skillRepository,
                                EducationRepository educationRepository,
                                ExperienceRepository experienceRepository,
                                ResumeStorageService resumeStorageService) {
        this.userRepository = userRepository;
        this.jobSeekerRepository = jobSeekerRepository;
        this.skillRepository = skillRepository;
        this.educationRepository = educationRepository;
        this.experienceRepository = experienceRepository;
        this.resumeStorageService = resumeStorageService;
    }

    private JobSeeker getJobSeekerByUserEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        return jobSeekerRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile", "userId", user.getId()));
    }

    @Override
    @Transactional(readOnly = true)
    public JobSeekerProfileResponse getProfileByEmail(String email) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        return mapToProfileResponse(seeker);
    }

    @Override
    @Transactional(readOnly = true)
    public JobSeekerProfileResponse getProfileByUserId(Long userId) {
        JobSeeker seeker = jobSeekerRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile", "userId", userId));
        return mapToProfileResponse(seeker);
    }

    @Override
    @Transactional
    public JobSeekerProfileResponse updateProfile(String email, ProfileUpdateRequest request) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        User user = seeker.getUser();

        if (request.getFullName() != null) user.setFullName(request.getFullName());
        if (request.getPhone() != null) user.setPhone(request.getPhone());
        userRepository.save(user);

        if (request.getTitle() != null) seeker.setTitle(request.getTitle());
        if (request.getBio() != null) seeker.setBio(request.getBio());
        if (request.getExperienceYears() != null) seeker.setExperienceYears(request.getExperienceYears());
        if (request.getExpectedSalary() != null) seeker.setExpectedSalary(request.getExpectedSalary());
        if (request.getLocation() != null) seeker.setLocation(request.getLocation());

        JobSeeker savedSeeker = jobSeekerRepository.save(seeker);
        return mapToProfileResponse(savedSeeker);
    }

    @Override
    @Transactional
    public String uploadResume(String email, MultipartFile file) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        String resumePath = resumeStorageService.storeFile(file, seeker.getUser().getId());
        seeker.setResumeUrl(resumePath);
        jobSeekerRepository.save(seeker);
        return resumePath;
    }

    @Override
    public Resource downloadResume(Long jobSeekerId) {
        JobSeeker seeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker", "id", jobSeekerId));
        if (seeker.getResumeUrl() == null) {
            throw new ResourceNotFoundException("Resume not found for job seeker id: " + jobSeekerId);
        }
        String fileName = seeker.getResumeUrl().substring(seeker.getResumeUrl().lastIndexOf('/') + 1);
        return resumeStorageService.loadFileAsResource(fileName);
    }

    @Override
    @Transactional
    public SkillDTO addSkill(String email, String skillName) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        String trimmedName = skillName.trim();
        
        Skill skill = skillRepository.findByName(trimmedName)
                .orElseGet(() -> skillRepository.save(new Skill(trimmedName)));

        seeker.getSkills().add(skill);
        jobSeekerRepository.save(seeker);

        return new SkillDTO(skill.getId(), skill.getName());
    }

    @Override
    @Transactional
    public void removeSkill(String email, Long skillId) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        Skill skill = skillRepository.findById(skillId)
                .orElseThrow(() -> new ResourceNotFoundException("Skill", "id", skillId));
        seeker.getSkills().remove(skill);
        jobSeekerRepository.save(seeker);
    }

    @Override
    @Transactional
    public EducationDTO addEducation(String email, EducationDTO dto) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        Education education = new Education(
                seeker,
                dto.getDegree(),
                dto.getInstitution(),
                dto.getFieldOfStudy(),
                dto.getStartYear(),
                dto.getEndYear(),
                dto.getGrade()
        );
        Education saved = educationRepository.save(education);
        dto.setId(saved.getId());
        return dto;
    }

    @Override
    @Transactional
    public EducationDTO updateEducation(String email, Long educationId, EducationDTO dto) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        Education edu = educationRepository.findById(educationId)
                .orElseThrow(() -> new ResourceNotFoundException("Education", "id", educationId));

        if (!edu.getJobSeeker().getId().equals(seeker.getId())) {
            throw new UnauthorizedAccessException("Not authorized to modify this education record");
        }

        edu.setDegree(dto.getDegree());
        edu.setInstitution(dto.getInstitution());
        edu.setFieldOfStudy(dto.getFieldOfStudy());
        edu.setStartYear(dto.getStartYear());
        edu.setEndYear(dto.getEndYear());
        edu.setGrade(dto.getGrade());

        Education updated = educationRepository.save(edu);
        dto.setId(updated.getId());
        return dto;
    }

    @Override
    @Transactional
    public void deleteEducation(String email, Long educationId) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        Education edu = educationRepository.findById(educationId)
                .orElseThrow(() -> new ResourceNotFoundException("Education", "id", educationId));
        if (!edu.getJobSeeker().getId().equals(seeker.getId())) {
            throw new UnauthorizedAccessException("Not authorized to delete this education record");
        }
        educationRepository.delete(edu);
    }

    @Override
    @Transactional
    public ExperienceDTO addExperience(String email, ExperienceDTO dto) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        Experience experience = new Experience(
                seeker,
                dto.getCompanyName(),
                dto.getJobTitle(),
                dto.getStartDate(),
                dto.getEndDate(),
                dto.isCurrent(),
                dto.getDescription()
        );
        Experience saved = experienceRepository.save(experience);
        dto.setId(saved.getId());
        return dto;
    }

    @Override
    @Transactional
    public ExperienceDTO updateExperience(String email, Long experienceId, ExperienceDTO dto) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        Experience exp = experienceRepository.findById(experienceId)
                .orElseThrow(() -> new ResourceNotFoundException("Experience", "id", experienceId));

        if (!exp.getJobSeeker().getId().equals(seeker.getId())) {
            throw new UnauthorizedAccessException("Not authorized to modify this experience record");
        }

        exp.setCompanyName(dto.getCompanyName());
        exp.setJobTitle(dto.getJobTitle());
        exp.setStartDate(dto.getStartDate());
        exp.setEndDate(dto.getEndDate());
        exp.setCurrent(dto.isCurrent());
        exp.setDescription(dto.getDescription());

        Experience updated = experienceRepository.save(exp);
        dto.setId(updated.getId());
        return dto;
    }

    @Override
    @Transactional
    public void deleteExperience(String email, Long experienceId) {
        JobSeeker seeker = getJobSeekerByUserEmail(email);
        Experience exp = experienceRepository.findById(experienceId)
                .orElseThrow(() -> new ResourceNotFoundException("Experience", "id", experienceId));
        if (!exp.getJobSeeker().getId().equals(seeker.getId())) {
            throw new UnauthorizedAccessException("Not authorized to delete this experience record");
        }
        experienceRepository.delete(exp);
    }

    private JobSeekerProfileResponse mapToProfileResponse(JobSeeker seeker) {
        List<SkillDTO> skillDTOs = seeker.getSkills().stream()
                .map(s -> new SkillDTO(s.getId(), s.getName()))
                .collect(Collectors.toList());

        List<EducationDTO> eduDTOs = educationRepository.findByJobSeekerId(seeker.getId()).stream()
                .map(e -> new EducationDTO(e.getId(), e.getDegree(), e.getInstitution(), e.getFieldOfStudy(), e.getStartYear(), e.getEndYear(), e.getGrade()))
                .collect(Collectors.toList());

        List<ExperienceDTO> expDTOs = experienceRepository.findByJobSeekerId(seeker.getId()).stream()
                .map(e -> new ExperienceDTO(e.getId(), e.getCompanyName(), e.getJobTitle(), e.getStartDate(), e.getEndDate(), e.isCurrent(), e.getDescription()))
                .collect(Collectors.toList());

        return new JobSeekerProfileResponse(
                seeker.getId(),
                seeker.getUser().getId(),
                seeker.getUser().getEmail(),
                seeker.getUser().getFullName(),
                seeker.getUser().getPhone(),
                seeker.getTitle(),
                seeker.getBio(),
                seeker.getResumeUrl(),
                seeker.getExperienceYears(),
                seeker.getExpectedSalary(),
                seeker.getLocation(),
                skillDTOs,
                eduDTOs,
                expDTOs
        );
    }
}
