package com.jobportal.service;

import com.jobportal.dto.request.LoginRequest;
import com.jobportal.dto.request.RegisterRequest;
import com.jobportal.dto.response.JwtAuthResponse;
import com.jobportal.dto.response.UserResponse;

public interface AuthService {
    UserResponse register(RegisterRequest registerRequest);
    JwtAuthResponse login(LoginRequest loginRequest);
    UserResponse getCurrentUser(String email);
}
