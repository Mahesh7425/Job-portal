package com.jobportal.service;

import com.jobportal.dto.request.RegisterRequest;
import com.jobportal.dto.response.DashboardStatsResponse;
import com.jobportal.dto.response.UserResponse;

import java.util.List;

public interface AdminService {
    DashboardStatsResponse getDashboardStats();
    List<UserResponse> getAllUsers();
    UserResponse updateUserStatus(Long userId, boolean active);
    void deleteUser(Long userId);
    UserResponse createUser(RegisterRequest request);
}
