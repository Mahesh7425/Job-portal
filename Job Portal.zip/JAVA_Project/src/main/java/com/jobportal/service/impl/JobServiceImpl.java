package com.jobportal.service.impl;

import com.jobportal.dao.JobJdbcDao;
import com.jobportal.dto.request.JobCreateRequest;
import com.jobportal.dto.request.JobSearchFilter;
import com.jobportal.dto.request.SkillDTO;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.entity.*;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.exception.UnauthorizedAccessException;
import com.jobportal.repository.*;
import com.jobportal.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;
    private final RecruiterRepository recruiterRepository;
    private final CompanyRepository companyRepository;
    private final SkillRepository skillRepository;
    private final UserRepository userRepository;
    private final JobJdbcDao jobJdbcDao;

    @Autowired
    public JobServiceImpl(JobRepository jobRepository,
                           RecruiterRepository recruiterRepository,
                           CompanyRepository companyRepository,
                           SkillRepository skillRepository,
                           UserRepository userRepository,
                           JobJdbcDao jobJdbcDao) {
        this.jobRepository = jobRepository;
        this.recruiterRepository = recruiterRepository;
        this.companyRepository = companyRepository;
        this.skillRepository = skillRepository;
        this.userRepository = userRepository;
        this.jobJdbcDao = jobJdbcDao;
    }

    private Recruiter getRecruiterByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        if (user.getRole() == Role.ROLE_ADMIN) {
            return null; // Admin has universal permission
        }
        return recruiterRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter profile", "userId", user.getId()));
    }

    @Override
    @Transactional
    public JobResponse createJob(String recruiterEmail, JobCreateRequest request) {
        Recruiter recruiter = getRecruiterByEmail(recruiterEmail);

        Company company = null;
        if (request.getCompanyId() != null) {
            company = companyRepository.findById(request.getCompanyId())
                    .orElseThrow(() -> new ResourceNotFoundException("Company", "id", request.getCompanyId()));
        } else if (recruiter != null && recruiter.getCompany() != null) {
            company = recruiter.getCompany();
        }

        Job job = new Job();
        job.setRecruiter(recruiter);
        job.setCompany(company);
        job.setTitle(request.getTitle());
        job.setDescription(request.getDescription());
        job.setLocation(request.getLocation());
        job.setSalaryMin(request.getSalaryMin());
        job.setSalaryMax(request.getSalaryMax());
        job.setExperienceRequired(request.getExperienceRequired());
        job.setEmploymentType(request.getEmploymentType());
        job.setActive(true);
        job.setSource(JobSource.DIRECT);
        job.setSourceName("Direct Posting");

        if (request.getSkillIds() != null && !request.getSkillIds().isEmpty()) {
            Set<Skill> skills = new HashSet<>(skillRepository.findAllById(request.getSkillIds()));
            job.setRequiredSkills(skills);
        }

        Job saved = jobRepository.save(job);
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public JobResponse updateJob(String recruiterEmail, Long jobId, JobCreateRequest request) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));

        Recruiter recruiter = getRecruiterByEmail(recruiterEmail);
        if (recruiter != null && (job.getRecruiter() == null || !job.getRecruiter().getId().equals(recruiter.getId()))) {
            throw new UnauthorizedAccessException("Not authorized to update this job listing");
        }

        job.setTitle(request.getTitle());
        job.setDescription(request.getDescription());
        job.setLocation(request.getLocation());
        job.setSalaryMin(request.getSalaryMin());
        job.setSalaryMax(request.getSalaryMax());
        job.setExperienceRequired(request.getExperienceRequired());
        job.setEmploymentType(request.getEmploymentType());

        if (request.getCompanyId() != null) {
            Company company = companyRepository.findById(request.getCompanyId())
                    .orElseThrow(() -> new ResourceNotFoundException("Company", "id", request.getCompanyId()));
            job.setCompany(company);
        }

        if (request.getSkillIds() != null) {
            Set<Skill> skills = new HashSet<>(skillRepository.findAllById(request.getSkillIds()));
            job.setRequiredSkills(skills);
        }

        Job updated = jobRepository.save(job);
        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public void deleteJob(String recruiterEmail, Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));

        Recruiter recruiter = getRecruiterByEmail(recruiterEmail);
        if (recruiter != null && (job.getRecruiter() == null || !job.getRecruiter().getId().equals(recruiter.getId()))) {
            throw new UnauthorizedAccessException("Not authorized to delete this job listing");
        }

        jobRepository.delete(job);
    }

    @Override
    @Transactional
    public JobResponse toggleJobStatus(String recruiterEmail, Long jobId, boolean active) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));

        Recruiter recruiter = getRecruiterByEmail(recruiterEmail);
        if (recruiter != null && (job.getRecruiter() == null || !job.getRecruiter().getId().equals(recruiter.getId()))) {
            throw new UnauthorizedAccessException("Not authorized to modify this job status");
        }

        job.setActive(active);
        Job saved = jobRepository.save(job);
        return mapToResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public JobResponse getJobById(Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));
        return mapToResponse(job);
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> searchJobs(JobSearchFilter filter) {
        List<JobResponse> content = jobJdbcDao.searchJobsWithJdbc(filter);
        int totalElements = jobJdbcDao.countSearchJobsWithJdbc(filter);
        int totalPages = (int) Math.ceil((double) totalElements / filter.getSize());

        Map<String, Object> response = new HashMap<>();
        response.put("content", content);
        response.put("pageNo", filter.getPage());
        response.put("pageSize", filter.getSize());
        response.put("totalElements", totalElements);
        response.put("totalPages", totalPages);
        response.put("last", filter.getPage() >= totalPages - 1);
        return response;
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobResponse> getJobsByRecruiter(String recruiterEmail) {
        Recruiter recruiter = getRecruiterByEmail(recruiterEmail);
        if (recruiter == null) {
            return jobRepository.findAll().stream().map(this::mapToResponse).collect(Collectors.toList());
        }
        return jobRepository.findByRecruiterId(recruiter.getId()).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobResponse> getJobsByCompany(Long companyId) {
        return jobRepository.findByCompanyId(companyId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private JobResponse mapToResponse(Job job) {
        List<SkillDTO> skills = job.getRequiredSkills().stream()
                .map(s -> new SkillDTO(s.getId(), s.getName()))
                .collect(Collectors.toList());

        Long recruiterId = job.getRecruiter() != null ? job.getRecruiter().getId() : null;
        Long companyId = job.getCompany() != null ? job.getCompany().getId() : null;
        String companyName = job.getCompany() != null ? job.getCompany().getName() : job.getCompanyNameExt();
        String logoUrl = job.getCompany() != null ? job.getCompany().getLogoUrl() : null;

        return new JobResponse(
                job.getId(),
                recruiterId,
                companyId,
                companyName,
                logoUrl,
                job.getTitle(),
                job.getDescription(),
                job.getLocation(),
                job.getSalaryMin(),
                job.getSalaryMax(),
                job.getExperienceRequired(),
                job.getEmploymentType(),
                job.isActive(),
                job.getSource(),
                job.getSourceName(),
                job.getExternalUrl(),
                job.getExternalId(),
                job.getCompanyNameExt(),
                job.getPostedAt(),
                skills
        );
    }
}
