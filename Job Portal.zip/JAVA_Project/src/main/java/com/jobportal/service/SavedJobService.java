package com.jobportal.service;

import com.jobportal.dto.response.JobResponse;
import java.util.List;

public interface SavedJobService {
    void saveJob(String seekerEmail, Long jobId);
    void unsaveJob(String seekerEmail, Long jobId);
    List<JobResponse> getSavedJobs(String seekerEmail);
    boolean isJobSaved(String seekerEmail, Long jobId);
}
