package com.jobportal.service;

import com.jobportal.dto.request.EducationDTO;
import com.jobportal.dto.request.ExperienceDTO;
import com.jobportal.dto.request.ProfileUpdateRequest;
import com.jobportal.dto.request.SkillDTO;
import com.jobportal.dto.response.JobSeekerProfileResponse;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface JobSeekerService {
    JobSeekerProfileResponse getProfileByEmail(String email);
    JobSeekerProfileResponse getProfileByUserId(Long userId);
    JobSeekerProfileResponse updateProfile(String email, ProfileUpdateRequest request);
    String uploadResume(String email, MultipartFile file);
    Resource downloadResume(Long jobSeekerId);
    
    SkillDTO addSkill(String email, String skillName);
    void removeSkill(String email, Long skillId);
    
    EducationDTO addEducation(String email, EducationDTO educationDTO);
    EducationDTO updateEducation(String email, Long educationId, EducationDTO educationDTO);
    void deleteEducation(String email, Long educationId);

    ExperienceDTO addExperience(String email, ExperienceDTO experienceDTO);
    ExperienceDTO updateExperience(String email, Long experienceId, ExperienceDTO experienceDTO);
    void deleteExperience(String email, Long experienceId);
}
