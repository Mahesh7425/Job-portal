package com.jobportal.service;

import com.jobportal.dto.response.RecruiterProfileResponse;

public interface RecruiterService {
    RecruiterProfileResponse getProfileByEmail(String email);
    RecruiterProfileResponse updateProfile(String email, String designation, Long companyId);
}
