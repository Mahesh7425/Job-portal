package com.jobportal.service.impl;

import com.jobportal.entity.ExternalSyncLog;
import com.jobportal.entity.Job;
import com.jobportal.entity.JobSource;
import com.jobportal.integration.ExternalJobDTO;
import com.jobportal.integration.ExternalJobProvider;
import com.jobportal.integration.ExternalJobProviderFactory;
import com.jobportal.repository.ExternalSyncLogRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.service.ExternalJobAggregationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ExternalJobAggregationServiceImpl implements ExternalJobAggregationService {

    private final JobRepository jobRepository;
    private final ExternalSyncLogRepository syncLogRepository;
    private final ExternalJobProviderFactory providerFactory;

    @Autowired
    public ExternalJobAggregationServiceImpl(JobRepository jobRepository,
                                             ExternalSyncLogRepository syncLogRepository,
                                             ExternalJobProviderFactory providerFactory) {
        this.jobRepository = jobRepository;
        this.syncLogRepository = syncLogRepository;
        this.providerFactory = providerFactory;
    }

    @Override
    @Transactional
    public ExternalSyncLog synchronizeExternalJobs() {
        ExternalJobProvider provider = providerFactory.getProvider();
        return executeSync(provider);
    }

    @Override
    @Transactional
    public ExternalSyncLog synchronizeExternalJobs(String providerOverride) {
        ExternalJobProvider provider = providerFactory.getProvider(providerOverride);
        return executeSync(provider);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExternalSyncLog> getSyncLogs() {
        return syncLogRepository.findAllByOrderBySyncTimeDesc();
    }

    private ExternalSyncLog executeSync(ExternalJobProvider provider) {
        long startTime = System.currentTimeMillis();
        int added = 0;
        int updated = 0;
        String status = "SUCCESS";
        String errorMessage = null;

        try {
            List<ExternalJobDTO> externalJobs = provider.fetchJobs();
            for (ExternalJobDTO dto : externalJobs) {
                Optional<Job> existingOpt = jobRepository.findByExternalIdAndSourceName(dto.getExternalId(), dto.getSourceName());
                if (existingOpt.isPresent()) {
                    Job job = existingOpt.get();
                    job.setTitle(dto.getTitle());
                    job.setDescription(dto.getDescription());
                    job.setLocation(dto.getLocation());
                    job.setSalaryMin(dto.getSalaryMin());
                    job.setSalaryMax(dto.getSalaryMax());
                    job.setCompanyNameExt(dto.getCompanyName());
                    job.setExternalUrl(dto.getExternalUrl());
                    jobRepository.save(job);
                    updated++;
                } else {
                    Job newJob = new Job();
                    newJob.setTitle(dto.getTitle());
                    newJob.setDescription(dto.getDescription());
                    newJob.setLocation(dto.getLocation());
                    newJob.setSalaryMin(dto.getSalaryMin());
                    newJob.setSalaryMax(dto.getSalaryMax());
                    newJob.setEmploymentType(dto.getEmploymentType());
                    newJob.setExperienceRequired(dto.getExperienceRequired() != null ? dto.getExperienceRequired() : 0);
                    newJob.setActive(true);
                    newJob.setSource(JobSource.EXTERNAL);
                    newJob.setSourceName(dto.getSourceName());
                    newJob.setExternalId(dto.getExternalId());
                    newJob.setExternalUrl(dto.getExternalUrl());
                    newJob.setCompanyNameExt(dto.getCompanyName());
                    newJob.setPostedAt(dto.getPostedAt() != null ? dto.getPostedAt() : LocalDateTime.now());
                    jobRepository.save(newJob);
                    added++;
                }
            }
        } catch (Exception ex) {
            status = "FAILED";
            errorMessage = ex.getMessage();
        }

        long durationMs = System.currentTimeMillis() - startTime;
        ExternalSyncLog log = new ExternalSyncLog(provider.getProviderName(), status, added, updated, durationMs, errorMessage);
        return syncLogRepository.save(log);
    }
}
