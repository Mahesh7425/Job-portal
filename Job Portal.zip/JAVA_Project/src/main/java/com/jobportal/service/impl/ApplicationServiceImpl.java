package com.jobportal.service.impl;

import com.jobportal.dao.ApplicationJdbcDao;
import com.jobportal.dto.request.ApplicationRequest;
import com.jobportal.dto.request.ApplicationStatusUpdateRequest;
import com.jobportal.dto.response.ApplicationResponse;
import com.jobportal.entity.*;
import com.jobportal.exception.DuplicateResourceException;
import com.jobportal.exception.InvalidApplicationException;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.exception.UnauthorizedAccessException;
import com.jobportal.repository.*;
import com.jobportal.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ApplicationServiceImpl implements ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final JobSeekerRepository jobSeekerRepository;
    private final RecruiterRepository recruiterRepository;
    private final UserRepository userRepository;
    private final ApplicationJdbcDao applicationJdbcDao;

    @Autowired
    public ApplicationServiceImpl(ApplicationRepository applicationRepository,
                                   JobRepository jobRepository,
                                   JobSeekerRepository jobSeekerRepository,
                                   RecruiterRepository recruiterRepository,
                                   UserRepository userRepository,
                                   ApplicationJdbcDao applicationJdbcDao) {
        this.applicationRepository = applicationRepository;
        this.jobRepository = jobRepository;
        this.jobSeekerRepository = jobSeekerRepository;
        this.recruiterRepository = recruiterRepository;
        this.userRepository = userRepository;
        this.applicationJdbcDao = applicationJdbcDao;
    }

    private JobSeeker getSeekerByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        return jobSeekerRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile", "userId", user.getId()));
    }

    private Recruiter getRecruiterByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        if (user.getRole() == Role.ROLE_ADMIN) {
            return null; // Admin
        }
        return recruiterRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter profile", "userId", user.getId()));
    }

    @Override
    @Transactional
    public ApplicationResponse applyForJob(String seekerEmail, ApplicationRequest request) {
        JobSeeker seeker = getSeekerByEmail(seekerEmail);
        Job job = jobRepository.findById(request.getJobId())
                .orElseThrow(() -> new ResourceNotFoundException("Job", "id", request.getJobId()));

        if (!job.isActive()) {
            throw new InvalidApplicationException("Cannot apply to an inactive job listing.");
        }

        if (applicationRepository.existsByJobIdAndJobSeekerId(job.getId(), seeker.getId())) {
            throw new DuplicateResourceException("You have already applied for this job position.");
        }

        Application application = new Application(job, seeker, request.getCoverLetter());
        Application saved = applicationRepository.save(application);
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public void withdrawApplication(String seekerEmail, Long applicationId) {
        JobSeeker seeker = getSeekerByEmail(seekerEmail);
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", applicationId));

        if (!application.getJobSeeker().getId().equals(seeker.getId())) {
            throw new UnauthorizedAccessException("Not authorized to withdraw this application.");
        }

        applicationRepository.delete(application);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationResponse> getMyApplications(String seekerEmail) {
        JobSeeker seeker = getSeekerByEmail(seekerEmail);
        return applicationRepository.findByJobSeekerId(seeker.getId()).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationResponse> getApplicantsForJob(String recruiterEmail, Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));

        Recruiter recruiter = getRecruiterByEmail(recruiterEmail);
        if (recruiter != null && (job.getRecruiter() == null || !job.getRecruiter().getId().equals(recruiter.getId()))) {
            throw new UnauthorizedAccessException("Not authorized to view applicants for this job.");
        }

        return applicationRepository.findByJobId(jobId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ApplicationResponse updateApplicationStatus(String recruiterEmail, Long applicationId, ApplicationStatusUpdateRequest request) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", applicationId));

        Recruiter recruiter = getRecruiterByEmail(recruiterEmail);
        if (recruiter != null && (application.getJob().getRecruiter() == null || !application.getJob().getRecruiter().getId().equals(recruiter.getId()))) {
            throw new UnauthorizedAccessException("Not authorized to modify this application status.");
        }

        // Demonstrate explicit MCA JDBC status update call
        boolean updatedViaJdbc = applicationJdbcDao.updateApplicationStatusWithJdbc(applicationId, request.getStatus());
        if (!updatedViaJdbc) {
            application.setStatus(request.getStatus());
            applicationRepository.save(application);
        }

        Application fresh = applicationRepository.findById(applicationId).orElse(application);
        return mapToResponse(fresh);
    }

    @Override
    @Transactional(readOnly = true)
    public ApplicationResponse getApplicationById(Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", applicationId));
        return mapToResponse(application);
    }

    private ApplicationResponse mapToResponse(Application app) {
        Job job = app.getJob();
        JobSeeker seeker = app.getJobSeeker();
        User user = seeker.getUser();

        String companyName = job.getCompany() != null ? job.getCompany().getName() : job.getCompanyNameExt();
        String logoUrl = job.getCompany() != null ? job.getCompany().getLogoUrl() : null;

        return new ApplicationResponse(
                app.getId(),
                job.getId(),
                job.getTitle(),
                companyName,
                logoUrl,
                job.getLocation(),
                job.getEmploymentType(),
                seeker.getId(),
                user.getFullName(),
                user.getEmail(),
                user.getPhone(),
                seeker.getTitle(),
                seeker.getResumeUrl(),
                app.getStatus(),
                app.getCoverLetter(),
                app.getAppliedAt(),
                app.getUpdatedAt()
        );
    }
}
