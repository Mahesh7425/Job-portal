package com.jobportal.service;

import com.jobportal.dto.request.ApplicationRequest;
import com.jobportal.dto.request.ApplicationStatusUpdateRequest;
import com.jobportal.dto.response.ApplicationResponse;
import com.jobportal.entity.ApplicationStatus;

import java.util.List;

public interface ApplicationService {
    ApplicationResponse applyForJob(String seekerEmail, ApplicationRequest request);
    void withdrawApplication(String seekerEmail, Long applicationId);
    List<ApplicationResponse> getMyApplications(String seekerEmail);
    List<ApplicationResponse> getApplicantsForJob(String recruiterEmail, Long jobId);
    ApplicationResponse updateApplicationStatus(String recruiterEmail, Long applicationId, ApplicationStatusUpdateRequest request);
    ApplicationResponse getApplicationById(Long applicationId);
}
