package com.jobportal.service;

import com.jobportal.dto.request.CompanyCreateRequest;
import com.jobportal.dto.response.CompanyResponse;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface CompanyService {
    CompanyResponse createCompany(CompanyCreateRequest request);
    CompanyResponse updateCompany(Long id, CompanyCreateRequest request);
    CompanyResponse getCompanyById(Long id);
    List<CompanyResponse> getAllCompanies();
    String uploadLogo(Long companyId, MultipartFile file);
    void deleteCompany(Long id);
}
