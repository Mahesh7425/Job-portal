package com.jobportal.service.impl;

import com.jobportal.dto.response.CompanyResponse;
import com.jobportal.dto.response.RecruiterProfileResponse;
import com.jobportal.entity.Company;
import com.jobportal.entity.Recruiter;
import com.jobportal.entity.User;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.CompanyRepository;
import com.jobportal.repository.RecruiterRepository;
import com.jobportal.repository.UserRepository;
import com.jobportal.service.RecruiterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RecruiterServiceImpl implements RecruiterService {

    private final UserRepository userRepository;
    private final RecruiterRepository recruiterRepository;
    private final CompanyRepository companyRepository;

    @Autowired
    public RecruiterServiceImpl(UserRepository userRepository,
                                RecruiterRepository recruiterRepository,
                                CompanyRepository companyRepository) {
        this.userRepository = userRepository;
        this.recruiterRepository = recruiterRepository;
        this.companyRepository = companyRepository;
    }

    private Recruiter getRecruiterByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        return recruiterRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter profile", "userId", user.getId()));
    }

    @Override
    @Transactional(readOnly = true)
    public RecruiterProfileResponse getProfileByEmail(String email) {
        Recruiter recruiter = getRecruiterByEmail(email);
        return mapToResponse(recruiter);
    }

    @Override
    @Transactional
    public RecruiterProfileResponse updateProfile(String email, String designation, Long companyId) {
        Recruiter recruiter = getRecruiterByEmail(email);
        if (designation != null) {
            recruiter.setDesignation(designation);
        }
        if (companyId != null) {
            Company company = companyRepository.findById(companyId)
                    .orElseThrow(() -> new ResourceNotFoundException("Company", "id", companyId));
            recruiter.setCompany(company);
        }

        Recruiter updated = recruiterRepository.save(recruiter);
        return mapToResponse(updated);
    }

    private RecruiterProfileResponse mapToResponse(Recruiter recruiter) {
        CompanyResponse companyResponse = null;
        if (recruiter.getCompany() != null) {
            Company c = recruiter.getCompany();
            companyResponse = new CompanyResponse(
                    c.getId(), c.getName(), c.getDescription(), c.getWebsite(),
                    c.getLocation(), c.getLogoUrl(), c.getIndustry(), c.getCreatedAt()
            );
        }

        return new RecruiterProfileResponse(
                recruiter.getId(),
                recruiter.getUser().getId(),
                recruiter.getUser().getEmail(),
                recruiter.getUser().getFullName(),
                recruiter.getUser().getPhone(),
                recruiter.getDesignation(),
                companyResponse
        );
    }
}
