package com.jobportal.service.impl;

import com.jobportal.dto.request.SkillDTO;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.entity.Job;
import com.jobportal.entity.JobSeeker;
import com.jobportal.entity.SavedJob;
import com.jobportal.entity.User;
import com.jobportal.exception.DuplicateResourceException;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.JobSeekerRepository;
import com.jobportal.repository.SavedJobRepository;
import com.jobportal.repository.UserRepository;
import com.jobportal.service.SavedJobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SavedJobServiceImpl implements SavedJobService {

    private final SavedJobRepository savedJobRepository;
    private final JobRepository jobRepository;
    private final JobSeekerRepository jobSeekerRepository;
    private final UserRepository userRepository;

    @Autowired
    public SavedJobServiceImpl(SavedJobRepository savedJobRepository,
                                JobRepository jobRepository,
                                JobSeekerRepository jobSeekerRepository,
                                UserRepository userRepository) {
        this.savedJobRepository = savedJobRepository;
        this.jobRepository = jobRepository;
        this.jobSeekerRepository = jobSeekerRepository;
        this.userRepository = userRepository;
    }

    private JobSeeker getSeekerByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        return jobSeekerRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile", "userId", user.getId()));
    }

    @Override
    @Transactional
    public void saveJob(String seekerEmail, Long jobId) {
        JobSeeker seeker = getSeekerByEmail(seekerEmail);
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job", "id", jobId));

        if (savedJobRepository.existsByJobSeekerIdAndJobId(seeker.getId(), job.getId())) {
            throw new DuplicateResourceException("Job is already saved in your bookmarks.");
        }

        SavedJob savedJob = new SavedJob(seeker, job);
        savedJobRepository.save(savedJob);
    }

    @Override
    @Transactional
    public void unsaveJob(String seekerEmail, Long jobId) {
        JobSeeker seeker = getSeekerByEmail(seekerEmail);
        savedJobRepository.deleteByJobSeekerIdAndJobId(seeker.getId(), jobId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobResponse> getSavedJobs(String seekerEmail) {
        JobSeeker seeker = getSeekerByEmail(seekerEmail);
        return savedJobRepository.findByJobSeekerId(seeker.getId()).stream()
                .map(sj -> mapJobToResponse(sj.getJob()))
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isJobSaved(String seekerEmail, Long jobId) {
        JobSeeker seeker = getSeekerByEmail(seekerEmail);
        return savedJobRepository.existsByJobSeekerIdAndJobId(seeker.getId(), jobId);
    }

    private JobResponse mapJobToResponse(Job job) {
        List<SkillDTO> skills = job.getRequiredSkills().stream()
                .map(s -> new SkillDTO(s.getId(), s.getName()))
                .collect(Collectors.toList());

        Long recruiterId = job.getRecruiter() != null ? job.getRecruiter().getId() : null;
        Long companyId = job.getCompany() != null ? job.getCompany().getId() : null;
        String companyName = job.getCompany() != null ? job.getCompany().getName() : job.getCompanyNameExt();
        String logoUrl = job.getCompany() != null ? job.getCompany().getLogoUrl() : null;

        return new JobResponse(
                job.getId(),
                recruiterId,
                companyId,
                companyName,
                logoUrl,
                job.getTitle(),
                job.getDescription(),
                job.getLocation(),
                job.getSalaryMin(),
                job.getSalaryMax(),
                job.getExperienceRequired(),
                job.getEmploymentType(),
                job.isActive(),
                job.getSource(),
                job.getSourceName(),
                job.getExternalUrl(),
                job.getExternalId(),
                job.getCompanyNameExt(),
                job.getPostedAt(),
                skills
        );
    }
}
