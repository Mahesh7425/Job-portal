package com.jobportal.service;

import com.jobportal.dto.request.JobCreateRequest;
import com.jobportal.dto.request.JobSearchFilter;
import com.jobportal.dto.response.JobResponse;

import java.util.List;
import java.util.Map;

public interface JobService {
    JobResponse createJob(String recruiterEmail, JobCreateRequest request);
    JobResponse updateJob(String recruiterEmail, Long jobId, JobCreateRequest request);
    void deleteJob(String recruiterEmail, Long jobId);
    JobResponse toggleJobStatus(String recruiterEmail, Long jobId, boolean active);
    JobResponse getJobById(Long jobId);
    Map<String, Object> searchJobs(JobSearchFilter filter);
    List<JobResponse> getJobsByRecruiter(String recruiterEmail);
    List<JobResponse> getJobsByCompany(Long companyId);
}
