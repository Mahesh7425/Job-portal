/* ===================================================
   ADMIN DASHBOARD LOGIC
   =================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const user = API.getUser();
  if (!user || user.role !== 'ROLE_ADMIN') {
    return;
  }
  loadAdminStats();
  loadAdminUsers();
  loadSyncLogs();
});

async function loadAdminStats() {
  try {
    const stats = await API.get('/admin/dashboard/stats');
    
    document.getElementById('statTotalUsers')?.replaceChildren(document.createTextNode(stats.totalUsers.toString()));
    document.getElementById('statTotalSeekers')?.replaceChildren(document.createTextNode(stats.totalJobSeekers.toString()));
    document.getElementById('statTotalRecruiters')?.replaceChildren(document.createTextNode(stats.totalRecruiters.toString()));
    document.getElementById('statTotalCompanies')?.replaceChildren(document.createTextNode(stats.totalCompanies.toString()));
    document.getElementById('statTotalJobs')?.replaceChildren(document.createTextNode(stats.totalJobs.toString()));
    document.getElementById('statActiveJobs')?.replaceChildren(document.createTextNode(stats.activeJobs.toString()));
    document.getElementById('statTotalApplications')?.replaceChildren(document.createTextNode(stats.totalApplications.toString()));

    const syncBadge = document.getElementById('syncLastStatusBadge');
    if (syncBadge && stats.lastSyncTime) {
      syncBadge.innerText = `Last Sync: ${new Date(stats.lastSyncTime).toLocaleString()} (${stats.lastSyncStatus})`;
      syncBadge.className = `sync-status-indicator ${stats.lastSyncStatus === 'SUCCESS' ? 'sync-status-success' : 'sync-status-failed'}`;
    }
  } catch (err) {
    console.error('Error loading admin stats:', err);
  }
}

async function loadAdminUsers() {
  const table = document.getElementById('adminUsersTableBody');
  if (!table) return;

  try {
    const users = await API.get('/admin/users');
    if (users.length === 0) {
      table.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:2rem; color:#64748b;">No users registered yet.</td></tr>';
      return;
    }

    table.innerHTML = users.map(u => `
      <tr>
        <td>#${u.id}</td>
        <td><strong>${escapeHtml(u.fullName)}</strong></td>
        <td>${escapeHtml(u.email)}</td>
        <td><span class="badge badge-direct">${u.role.replace('ROLE_', '')}</span></td>
        <td><span class="badge ${u.active ? 'badge-shortlisted' : 'badge-rejected'}">${u.active ? 'Active' : 'Disabled'}</span></td>
        <td>
          <button onclick="toggleUserActive(${u.id}, ${!u.active})" class="btn btn-outline btn-sm">${u.active ? 'Disable' : 'Enable'}</button>
          <button onclick="deleteUser(${u.id})" class="btn btn-danger btn-sm">Delete</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error loading admin users:', err);
  }
}

async function toggleUserActive(userId, active) {
  try {
    await API.patch(`/admin/users/${userId}/status`, { active });
    loadAdminUsers();
    loadAdminStats();
  } catch (err) {
    alert('Failed to update user status: ' + err.message);
  }
}

async function deleteUser(userId) {
  if (!confirm('Are you sure you want to delete this user? This will also remove their profile and associated applications.')) return;
  try {
    await API.delete(`/admin/users/${userId}`);
    alert('User deleted.');
    loadAdminUsers();
    loadAdminStats();
  } catch (err) {
    alert('Failed to delete user: ' + err.message);
  }
}

async function triggerManualSync() {
  const btn = document.getElementById('btnSyncNow');
  if (btn) {
    btn.disabled = true;
    btn.innerText = 'Synchronizing...';
  }

  try {
    const res = await API.post('/admin/sync-now', {});
    alert(`External job sync complete!\nProvider: ${res.providerName}\nStatus: ${res.status}\nJobs Added: ${res.jobsAdded}\nJobs Updated: ${res.jobsUpdated}\nDuration: ${res.executionDurationMs}ms`);
    loadAdminStats();
    loadSyncLogs();
  } catch (err) {
    alert('Synchronization failed: ' + err.message);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerText = '⚡ Trigger Sync Now';
    }
  }
}

async function loadSyncLogs() {
  const table = document.getElementById('syncLogsTableBody');
  if (!table) return;

  try {
    const logs = await API.get('/admin/sync-logs');
    if (logs.length === 0) {
      table.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:2rem; color:#64748b;">No sync logs recorded yet.</td></tr>';
      return;
    }

    table.innerHTML = logs.map(l => `
      <tr>
        <td>${new Date(l.syncTime).toLocaleString()}</td>
        <td><strong>${escapeHtml(l.providerName)}</strong></td>
        <td><span class="sync-status-indicator ${l.status === 'SUCCESS' ? 'sync-status-success' : 'sync-status-failed'}">${l.status}</span></td>
        <td>+${l.jobsAdded}</td>
        <td>~${l.jobsUpdated}</td>
        <td>${l.executionDurationMs} ms</td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error loading sync logs:', err);
  }
}
