/* ===================================================
   JOB SEEKER DASHBOARD LOGIC
   =================================================== */

document.addEventListener('DOMContentLoaded', async () => {
  const user = API.getUser();
  if (!user || (user.role !== 'ROLE_JOB_SEEKER' && user.role !== 'ROLE_ADMIN')) {
    return;
  }
  loadSeekerProfile();
  loadAppliedJobs();
  loadSavedJobs();
});

async function loadSeekerProfile() {
  try {
    const profile = await API.get('/job-seeker/profile');
    
    document.getElementById('seekerName')?.replaceChildren(document.createTextNode(profile.fullName || ''));
    document.getElementById('seekerEmail')?.replaceChildren(document.createTextNode(profile.email || ''));
    document.getElementById('seekerPhone')?.replaceChildren(document.createTextNode(profile.phone || 'N/A'));
    document.getElementById('seekerTitle')?.replaceChildren(document.createTextNode(profile.title || 'Not specified'));
    document.getElementById('seekerBio')?.replaceChildren(document.createTextNode(profile.bio || 'No bio added yet.'));
    document.getElementById('seekerLocation')?.replaceChildren(document.createTextNode(profile.location || 'Not specified'));

    const resumeLink = document.getElementById('resumeDownloadLink');
    if (resumeLink && profile.resumeUrl) {
      resumeLink.href = `/api/job-seeker/resume/${profile.id}`;
      resumeLink.style.display = 'inline-flex';
    }

    // Render Skills
    const skillsContainer = document.getElementById('skillsBadgeContainer');
    if (skillsContainer) {
      skillsContainer.innerHTML = (profile.skills || []).map(s => `
        <span class="tag" style="background:#e2e8f0; color:#1e293b; padding:0.4rem 0.75rem; border-radius:999px;">
          ${s.name} <button onclick="removeSkill(${s.id})" style="border:none; background:none; cursor:pointer; color:#ef4444; font-weight:bold; margin-left:4px;">&times;</button>
        </span>
      `).join('');
    }

    // Render Education
    const eduList = document.getElementById('educationListContainer');
    if (eduList) {
      eduList.innerHTML = (profile.educationList || []).map(e => `
        <div style="border-bottom:1px solid #e2e8f0; padding:0.75rem 0;">
          <strong>${e.degree}</strong> - ${e.institution} (${e.startYear || ''} - ${e.endYear || 'Present'})
          <p style="font-size:0.85rem; color:#64748b;">${e.fieldOfStudy || ''} • Grade: ${e.grade || 'N/A'}</p>
        </div>
      `).join('');
    }

    // Render Experience
    const expList = document.getElementById('experienceListContainer');
    if (expList) {
      expList.innerHTML = (profile.experienceList || []).map(e => `
        <div style="border-bottom:1px solid #e2e8f0; padding:0.75rem 0;">
          <strong>${e.jobTitle}</strong> at ${e.companyName}
          <p style="font-size:0.85rem; color:#64748b;">${e.startDate || ''} to ${e.isCurrent ? 'Present' : (e.endDate || '')}</p>
          <p style="font-size:0.9rem;">${e.description || ''}</p>
        </div>
      `).join('');
    }
  } catch (err) {
    console.error('Error loading seeker profile:', err);
  }
}

async function handleProfileUpdate(event) {
  event.preventDefault();
  const title = document.getElementById('editTitle').value;
  const bio = document.getElementById('editBio').value;
  const phone = document.getElementById('editPhone').value;
  const location = document.getElementById('editLocation').value;
  const expYears = document.getElementById('editExpYears').value;

  try {
    await API.put('/job-seeker/profile', {
      title, bio, phone, location, experienceYears: parseInt(expYears || 0)
    });
    alert('Profile updated successfully!');
    closeModal('editProfileModal');
    loadSeekerProfile();
  } catch (err) {
    alert('Failed to update profile: ' + err.message);
  }
}

async function handleResumeUpload(event) {
  event.preventDefault();
  const fileInput = document.getElementById('resumeFileInput');
  if (!fileInput.files[0]) return alert('Please select a resume file');

  const formData = new FormData();
  formData.append('file', fileInput.files[0]);

  try {
    await API.post('/job-seeker/resume', formData);
    alert('Resume uploaded successfully!');
    loadSeekerProfile();
  } catch (err) {
    alert('Resume upload failed: ' + err.message);
  }
}

async function addSkillPrompt() {
  const skillName = prompt('Enter skill name (e.g. Java, Spring Boot, MySQL):');
  if (!skillName || !skillName.trim()) return;

  try {
    await API.post('/job-seeker/skills', { name: skillName.trim() });
    loadSeekerProfile();
  } catch (err) {
    alert('Error adding skill: ' + err.message);
  }
}

async function removeSkill(skillId) {
  try {
    await API.delete(`/job-seeker/skills/${skillId}`);
    loadSeekerProfile();
  } catch (err) {
    alert('Error removing skill: ' + err.message);
  }
}

async function loadAppliedJobs() {
  const table = document.getElementById('appliedJobsTableBody');
  if (!table) return;

  try {
    const apps = await API.get('/applications/my-applications');
    if (apps.length === 0) {
      table.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:2rem; color:#64748b;">No applications submitted yet.</td></tr>';
      return;
    }

    table.innerHTML = apps.map(a => `
      <tr>
        <td><strong>${escapeHtml(a.jobTitle)}</strong></td>
        <td>${escapeHtml(a.companyName || 'N/A')}</td>
        <td>${new Date(a.appliedAt).toLocaleDateString()}</td>
        <td><span class="badge ${getStatusBadgeClass(a.status)}">${a.status}</span></td>
        <td>
          <button onclick="withdrawApplication(${a.id})" class="btn btn-danger btn-sm">Withdraw</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error loading applied jobs:', err);
  }
}

async function withdrawApplication(appId) {
  if (!confirm('Are you sure you want to withdraw this application?')) return;
  try {
    await API.delete(`/applications/${appId}`);
    alert('Application withdrawn.');
    loadAppliedJobs();
  } catch (err) {
    alert('Withdrawal failed: ' + err.message);
  }
}

async function loadSavedJobs() {
  const container = document.getElementById('savedJobsGrid');
  if (!container) return;

  try {
    const saved = await API.get('/saved-jobs');
    if (saved.length === 0) {
      container.innerHTML = '<div style="padding:2rem; color:#64748b;">No saved jobs bookmarked yet.</div>';
      return;
    }

    container.innerHTML = saved.map(j => renderJobCard(j)).join('');
  } catch (err) {
    console.error('Error loading saved jobs:', err);
  }
}

function getStatusBadgeClass(status) {
  switch(status) {
    case 'APPLIED': return 'badge-applied';
    case 'UNDER_REVIEW': return 'badge-review';
    case 'SHORTLISTED': return 'badge-shortlisted';
    case 'REJECTED': return 'badge-rejected';
    case 'SELECTED': return 'badge-selected';
    default: return 'badge-applied';
  }
}
