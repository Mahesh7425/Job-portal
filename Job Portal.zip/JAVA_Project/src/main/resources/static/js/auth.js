/* ===================================================
   AUTHENTICATION & NAVBAR ROLE MANAGEMENT
   =================================================== */

document.addEventListener('DOMContentLoaded', () => {
  renderNavbar();
});

function renderNavbar() {
  const navAuthContainer = document.getElementById('navAuthContainer');
  if (!navAuthContainer) return;

  const user = API.getUser();

  if (user) {
    let dashboardUrl = '/seeker-dashboard.html';
    if (user.role === 'ROLE_RECRUITER') dashboardUrl = '/recruiter-dashboard.html';
    if (user.role === 'ROLE_ADMIN') dashboardUrl = '/admin-dashboard.html';

    navAuthContainer.innerHTML = `
      <span style="color:#94a3b8; font-size:0.9rem;">Hello, <strong>${user.fullName}</strong></span>
      <a href="${dashboardUrl}" class="btn btn-outline btn-sm" style="color:#fff; border-color:#475569;">Dashboard</a>
      <button onclick="API.logout()" class="btn btn-danger btn-sm">Logout</button>
    `;
  } else {
    navAuthContainer.innerHTML = `
      <a href="/login.html" class="btn btn-outline btn-sm" style="color:#fff; border-color:#475569;">Login</a>
      <a href="/register.html" class="btn btn-primary btn-sm">Register</a>
    `;
  }
}
