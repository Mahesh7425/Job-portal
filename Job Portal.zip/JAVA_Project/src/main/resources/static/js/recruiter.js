/* ===================================================
   RECRUITER DASHBOARD LOGIC
   =================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const user = API.getUser();
  if (!user || (user.role !== 'ROLE_RECRUITER' && user.role !== 'ROLE_ADMIN')) {
    return;
  }
  loadRecruiterProfile();
  loadRecruiterJobs();
});

async function loadRecruiterProfile() {
  try {
    const profile = await API.get('/recruiter/profile');
    document.getElementById('recruiterName')?.replaceChildren(document.createTextNode(profile.fullName || ''));
    document.getElementById('recruiterEmail')?.replaceChildren(document.createTextNode(profile.email || ''));
    document.getElementById('recruiterDesignation')?.replaceChildren(document.createTextNode(profile.designation || 'Technical Recruiter'));

    if (profile.company) {
      document.getElementById('companyNameDisplay')?.replaceChildren(document.createTextNode(profile.company.name || ''));
      document.getElementById('companyLocationDisplay')?.replaceChildren(document.createTextNode(profile.company.location || ''));
    }
  } catch (err) {
    console.error('Error loading recruiter profile:', err);
  }
}

async function loadRecruiterJobs() {
  const table = document.getElementById('recruiterJobsTableBody');
  if (!table) return;

  try {
    const jobs = await API.get('/jobs/recruiter');
    if (jobs.length === 0) {
      table.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:2rem; color:#64748b;">No jobs posted yet. Click "Post New Job" to list a position.</td></tr>';
      return;
    }

    table.innerHTML = jobs.map(j => `
      <tr>
        <td><strong>${escapeHtml(j.title)}</strong></td>
        <td>${escapeHtml(j.location)}</td>
        <td>${j.employmentType}</td>
        <td><span class="badge ${j.active ? 'badge-shortlisted' : 'badge-rejected'}">${j.active ? 'Active' : 'Inactive'}</span></td>
        <td>${new Date(j.postedAt).toLocaleDateString()}</td>
        <td>
          <button onclick="viewApplicants(${j.id}, '${escapeHtml(j.title)}')" class="btn btn-primary btn-sm">Applicants</button>
          <button onclick="toggleJobActive(${j.id}, ${!j.active})" class="btn btn-outline btn-sm">${j.active ? 'Deactivate' : 'Activate'}</button>
          <button onclick="deleteJob(${j.id})" class="btn btn-danger btn-sm">Delete</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error loading recruiter jobs:', err);
  }
}

async function handlePostJob(event) {
  event.preventDefault();
  const title = document.getElementById('jobTitle').value;
  const description = document.getElementById('jobDescription').value;
  const location = document.getElementById('jobLocation').value;
  const salaryMin = document.getElementById('jobSalaryMin').value;
  const salaryMax = document.getElementById('jobSalaryMax').value;
  const expReq = document.getElementById('jobExpReq').value;
  const empType = document.getElementById('jobEmpType').value;

  try {
    await API.post('/jobs', {
      title,
      description,
      location,
      salaryMin: salaryMin ? parseFloat(salaryMin) : null,
      salaryMax: salaryMax ? parseFloat(salaryMax) : null,
      experienceRequired: parseInt(expReq || 0),
      employmentType: empType
    });

    alert('Job position posted successfully!');
    closeModal('postJobModal');
    loadRecruiterJobs();
  } catch (err) {
    alert('Failed to post job: ' + err.message);
  }
}

async function toggleJobActive(jobId, active) {
  try {
    await API.patch(`/jobs/${jobId}/status`, { active });
    loadRecruiterJobs();
  } catch (err) {
    alert('Failed to update status: ' + err.message);
  }
}

async function deleteJob(jobId) {
  if (!confirm('Are you sure you want to delete this job post?')) return;
  try {
    await API.delete(`/jobs/${jobId}`);
    alert('Job deleted.');
    loadRecruiterJobs();
  } catch (err) {
    alert('Failed to delete job: ' + err.message);
  }
}

async function viewApplicants(jobId, jobTitle) {
  const modalTitle = document.getElementById('applicantsModalTitle');
  const modalBody = document.getElementById('applicantsListContainer');
  if (modalTitle) modalTitle.innerText = `Applicants for "${jobTitle}"`;

  if (modalBody) {
    modalBody.innerHTML = '<div style="padding:1.5rem; text-align:center; color:#64748b;">Loading applicants...</div>';
    openModal('applicantsModal');

    try {
      const applicants = await API.get(`/applications/job/${jobId}`);
      if (applicants.length === 0) {
        modalBody.innerHTML = '<div style="padding:2rem; text-align:center; color:#64748b;">No candidate applications received yet.</div>';
        return;
      }

      modalBody.innerHTML = applicants.map(a => `
        <div style="border:1px solid #e2e8f0; border-radius:8px; padding:1.25rem; margin-bottom:1rem; background:#fff;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <div>
              <h4 style="font-size:1.1rem; margin-bottom:0.25rem;">${escapeHtml(a.seekerName)}</h4>
              <p style="font-size:0.9rem; color:#64748b;">📧 ${escapeHtml(a.seekerEmail)} | 📞 ${escapeHtml(a.seekerPhone || 'N/A')}</p>
              <p style="font-size:0.9rem; font-weight:600; color:#2563eb;">${escapeHtml(a.seekerTitle || 'Job Seeker')}</p>
            </div>
            <div>
              <select onchange="updateApplicantStatus(${a.id}, this.value)" class="form-control" style="width:auto; font-size:0.85rem; padding:0.4rem 0.6rem;">
                <option value="APPLIED" ${a.status === 'APPLIED' ? 'selected' : ''}>APPLIED</option>
                <option value="UNDER_REVIEW" ${a.status === 'UNDER_REVIEW' ? 'selected' : ''}>UNDER_REVIEW</option>
                <option value="SHORTLISTED" ${a.status === 'SHORTLISTED' ? 'selected' : ''}>SHORTLISTED</option>
                <option value="SELECTED" ${a.status === 'SELECTED' ? 'selected' : ''}>SELECTED</option>
                <option value="REJECTED" ${a.status === 'REJECTED' ? 'selected' : ''}>REJECTED</option>
              </select>
            </div>
          </div>
          ${a.coverLetter ? `<p style="font-size:0.875rem; background:#f8fafc; padding:0.75rem; border-radius:6px; margin:0.75rem 0;"><strong>Cover Letter:</strong> ${escapeHtml(a.coverLetter)}</p>` : ''}
          ${a.resumeUrl ? `<a href="/api/job-seeker/resume/${a.seekerId}" target="_blank" class="btn btn-outline btn-sm" style="margin-top:0.5rem;">📄 Download Resume</a>` : '<span style="font-size:0.8rem; color:#94a3b8;">No resume uploaded</span>'}
        </div>
      `).join('');
    } catch (err) {
      modalBody.innerHTML = `<div class="alert alert-danger">Error loading applicants: ${err.message}</div>`;
    }
  }
}

async function updateApplicantStatus(appId, status) {
  try {
    await API.put(`/applications/${appId}/status`, { status });
    alert('Candidate application status updated to: ' + status);
  } catch (err) {
    alert('Failed to update status: ' + err.message);
  }
}
