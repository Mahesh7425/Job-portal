/* ===================================================
   DYNAMIC JOB LISTING & SEARCH COMPONENT
   =================================================== */

let currentPage = 0;
const pageSize = 9;

async function loadJobs(page = 0) {
  currentPage = page;
  const grid = document.getElementById('jobsGrid');
  const pagination = document.getElementById('paginationContainer');
  if (!grid) return;

  grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding: 3rem; color:#64748b;">Loading jobs...</div>';

  try {
    const keyword = document.getElementById('searchKeyword')?.value || '';
    const location = document.getElementById('searchLocation')?.value || '';
    const type = document.getElementById('searchType')?.value || '';
    const source = document.getElementById('searchSource')?.value || '';

    let query = `?page=${page}&size=${pageSize}`;
    if (keyword) query += `&keyword=${encodeURIComponent(keyword)}`;
    if (location) query += `&location=${encodeURIComponent(location)}`;
    if (type) query += `&employmentType=${encodeURIComponent(type)}`;
    if (source) query += `&source=${encodeURIComponent(source)}`;

    const res = await API.get(`/jobs${query}`);
    const jobs = res.content || [];

    if (jobs.length === 0) {
      grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding: 4rem; background:#fff; border-radius:12px;"><h3>No jobs found matching your criteria</h3><p style="color:#64748b;">Try adjusting your keyword or filter options.</p></div>';
      if (pagination) pagination.innerHTML = '';
      return;
    }

    grid.innerHTML = jobs.map(j => renderJobCard(j)).join('');

    if (pagination) {
      renderPagination(res.pageNo, res.totalPages);
    }
  } catch (err) {
    grid.innerHTML = `<div class="alert alert-danger" style="grid-column: 1/-1;">Error loading jobs: ${err.message}</div>`;
  }
}

function renderJobCard(job) {
  const isExternal = job.source === 'EXTERNAL';
  const badgeClass = isExternal ? 'badge-external' : 'badge-direct';
  const badgeLabel = isExternal ? `External (${job.sourceName || 'API'})` : 'Direct Job';
  const companyLogo = job.companyLogoUrl || '/uploads/logos/default.png';

  const salary = (job.salaryMin || job.salaryMax) 
    ? `$${job.salaryMin ? job.salaryMin.toLocaleString() : '0'} - $${job.salaryMax ? job.salaryMax.toLocaleString() : '0'}`
    : 'Salary Negotiable';

  return `
    <div class="card">
      <div class="card-header">
        <div>
          <span class="badge ${badgeClass}">${badgeLabel}</span>
          <h3 class="card-title" style="margin-top:0.5rem;"><a href="/job-details.html?id=${job.id}">${escapeHtml(job.title)}</a></h3>
          <div class="card-company">${escapeHtml(job.companyName || 'Featured Company')}</div>
        </div>
        <img src="${companyLogo}" alt="Logo" class="card-company-logo" onerror="this.src='https://via.placeholder.com/48?text=Job';" />
      </div>

      <div style="font-size: 0.9rem; color: #475569; margin: 0.75rem 0;">
        <div>📍 ${escapeHtml(job.location)}</div>
        <div>💼 ${job.employmentType} • Exp: ${job.experienceRequired}+ yrs</div>
        <div style="font-weight:700; color:#1e293b; margin-top:0.25rem;">💰 ${salary}</div>
      </div>

      <p style="font-size:0.875rem; color:#64748b; line-clamp:2; -webkit-line-clamp:2; display:-webkit-box; -webkit-box-orient:vertical; overflow:hidden; margin-bottom:1rem;">
        ${escapeHtml(job.description || '')}
      </p>

      <div style="margin-top:auto; display:flex; justify-content:space-between; align-items:center; padding-top:0.75rem; border-top:1px solid #f1f5f9;">
        <span style="font-size:0.8rem; color:#94a3b8;">${new Date(job.postedAt).toLocaleDateString()}</span>
        <a href="/job-details.html?id=${job.id}" class="btn btn-outline btn-sm">View Details</a>
      </div>
    </div>
  `;
}

function renderPagination(current, total) {
  const container = document.getElementById('paginationContainer');
  if (!container) return;

  let html = '<div style="display:flex; gap:0.5rem; justify-content:center; margin-top:2rem;">';
  for (let i = 0; i < total; i++) {
    const active = i === current ? 'btn-primary' : 'btn-outline';
    html += `<button onclick="loadJobs(${i})" class="btn ${active} btn-sm">${i + 1}</button>`;
  }
  html += '</div>';
  container.innerHTML = html;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
