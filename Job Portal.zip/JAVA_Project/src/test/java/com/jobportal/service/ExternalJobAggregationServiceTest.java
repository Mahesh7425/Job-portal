package com.jobportal.service;

import com.jobportal.entity.ExternalSyncLog;
import com.jobportal.entity.Job;
import com.jobportal.integration.ExternalJobDTO;
import com.jobportal.integration.ExternalJobProvider;
import com.jobportal.integration.ExternalJobProviderFactory;
import com.jobportal.repository.ExternalSyncLogRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.service.impl.ExternalJobAggregationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExternalJobAggregationServiceTest {

    @Mock
    private JobRepository jobRepository;
    @Mock
    private ExternalSyncLogRepository syncLogRepository;
    @Mock
    private ExternalJobProviderFactory providerFactory;
    @Mock
    private ExternalJobProvider mockProvider;

    @InjectMocks
    private ExternalJobAggregationServiceImpl syncService;

    private ExternalJobDTO externalJobDTO;

    @BeforeEach
    void setUp() {
        externalJobDTO = new ExternalJobDTO("ext-100", "Mock Feed", "Acme", "https://acme.com", "Java Lead", "Desc", "Remote", null, null, null, 3, null);
    }

    @Test
    void testSynchronizeExternalJobs_NewJobInserted() {
        when(providerFactory.getProvider()).thenReturn(mockProvider);
        when(mockProvider.getProviderName()).thenReturn("Mock Feed");
        when(mockProvider.fetchJobs()).thenReturn(Collections.singletonList(externalJobDTO));
        when(jobRepository.findByExternalIdAndSourceName("ext-100", "Mock Feed")).thenReturn(Optional.empty());

        ExternalSyncLog mockLog = new ExternalSyncLog("Mock Feed", "SUCCESS", 1, 0, 50L, null);
        when(syncLogRepository.save(any(ExternalSyncLog.class))).thenReturn(mockLog);

        ExternalSyncLog log = syncService.synchronizeExternalJobs();

        assertNotNull(log);
        assertEquals("SUCCESS", log.getStatus());
        assertEquals(1, log.getJobsAdded());
        verify(jobRepository, times(1)).save(any(Job.class));
    }
}
