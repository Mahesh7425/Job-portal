package com.jobportal.service;

import com.jobportal.dao.JobJdbcDao;
import com.jobportal.dto.request.JobCreateRequest;
import com.jobportal.dto.request.JobSearchFilter;
import com.jobportal.dto.response.JobResponse;
import com.jobportal.entity.*;
import com.jobportal.repository.*;
import com.jobportal.service.impl.JobServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JobServiceTest {

    @Mock
    private JobRepository jobRepository;
    @Mock
    private RecruiterRepository recruiterRepository;
    @Mock
    private CompanyRepository companyRepository;
    @Mock
    private SkillRepository skillRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private JobJdbcDao jobJdbcDao;

    @InjectMocks
    private JobServiceImpl jobService;

    private User recruiterUser;
    private Recruiter recruiter;
    private Company company;
    private Job testJob;
    private JobCreateRequest createRequest;

    @BeforeEach
    void setUp() {
        recruiterUser = new User(2L, "recruiter@example.com", "pass", "Recruiter Name", "+123", Role.ROLE_RECRUITER, true);
        company = new Company(1L, "TechCorp", "Desc", "https://techcorp.com", "SF", "/logo.png", "Tech");
        recruiter = new Recruiter(recruiterUser, company, "Talent Acquisition");

        testJob = new Job();
        testJob.setId(10L);
        testJob.setRecruiter(recruiter);
        testJob.setCompany(company);
        testJob.setTitle("Java Developer");
        testJob.setDescription("Job Desc");
        testJob.setLocation("Remote");
        testJob.setSalaryMin(new BigDecimal("100000"));
        testJob.setSalaryMax(new BigDecimal("130000"));
        testJob.setEmploymentType(EmploymentType.REMOTE);

        createRequest = new JobCreateRequest("Java Developer", "Job Desc", "Remote", new BigDecimal("100000"), new BigDecimal("130000"), 2, EmploymentType.REMOTE, 1L, Collections.emptySet());
    }

    @Test
    void testCreateJob_Success() {
        when(userRepository.findByEmail("recruiter@example.com")).thenReturn(Optional.of(recruiterUser));
        when(recruiterRepository.findByUser(recruiterUser)).thenReturn(Optional.of(recruiter));
        when(companyRepository.findById(1L)).thenReturn(Optional.of(company));
        when(jobRepository.save(any(Job.class))).thenReturn(testJob);

        JobResponse response = jobService.createJob("recruiter@example.com", createRequest);

        assertNotNull(response);
        assertEquals("Java Developer", response.getTitle());
        assertEquals("Remote", response.getLocation());
    }

    @Test
    void testGetJobById_Success() {
        when(jobRepository.findById(10L)).thenReturn(Optional.of(testJob));

        JobResponse response = jobService.getJobById(10L);

        assertNotNull(response);
        assertEquals(10L, response.getId());
        assertEquals("Java Developer", response.getTitle());
    }

    @Test
    void testSearchJobs_UsesJdbcDao() {
        JobSearchFilter filter = new JobSearchFilter();
        when(jobJdbcDao.searchJobsWithJdbc(filter)).thenReturn(Collections.singletonList(new JobResponse()));
        when(jobJdbcDao.countSearchJobsWithJdbc(filter)).thenReturn(1);

        Map<String, Object> result = jobService.searchJobs(filter);

        assertNotNull(result);
        assertEquals(1, result.get("totalElements"));
        verify(jobJdbcDao, times(1)).searchJobsWithJdbc(filter);
    }
}
