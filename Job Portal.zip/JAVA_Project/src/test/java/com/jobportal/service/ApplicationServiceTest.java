package com.jobportal.service;

import com.jobportal.dao.ApplicationJdbcDao;
import com.jobportal.dto.request.ApplicationRequest;
import com.jobportal.dto.request.ApplicationStatusUpdateRequest;
import com.jobportal.dto.response.ApplicationResponse;
import com.jobportal.entity.*;
import com.jobportal.exception.DuplicateResourceException;
import com.jobportal.repository.*;
import com.jobportal.service.impl.ApplicationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationServiceTest {

    @Mock
    private ApplicationRepository applicationRepository;
    @Mock
    private JobRepository jobRepository;
    @Mock
    private JobSeekerRepository jobSeekerRepository;
    @Mock
    private RecruiterRepository recruiterRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private ApplicationJdbcDao applicationJdbcDao;

    @InjectMocks
    private ApplicationServiceImpl applicationService;

    private User seekerUser;
    private JobSeeker seeker;
    private Job job;
    private Application application;

    @BeforeEach
    void setUp() {
        seekerUser = new User(3L, "seeker@example.com", "pass", "Alex Seeker", "+123", Role.ROLE_JOB_SEEKER, true);
        seeker = new JobSeeker(seekerUser);
        seeker.setId(5L);

        job = new Job();
        job.setId(100L);
        job.setTitle("Spring Developer");
        job.setActive(true);

        application = new Application(job, seeker, "I am interested");
        application.setId(50L);
    }

    @Test
    void testApplyForJob_Success() {
        when(userRepository.findByEmail("seeker@example.com")).thenReturn(Optional.of(seekerUser));
        when(jobSeekerRepository.findByUser(seekerUser)).thenReturn(Optional.of(seeker));
        when(jobRepository.findById(100L)).thenReturn(Optional.of(job));
        when(applicationRepository.existsByJobIdAndJobSeekerId(100L, 5L)).thenReturn(false);
        when(applicationRepository.save(any(Application.class))).thenReturn(application);

        ApplicationResponse response = applicationService.applyForJob("seeker@example.com", new ApplicationRequest(100L, "Cover letter"));

        assertNotNull(response);
        assertEquals(50L, response.getId());
        assertEquals("Spring Developer", response.getJobTitle());
    }

    @Test
    void testApplyForJob_AlreadyApplied_ThrowsException() {
        when(userRepository.findByEmail("seeker@example.com")).thenReturn(Optional.of(seekerUser));
        when(jobSeekerRepository.findByUser(seekerUser)).thenReturn(Optional.of(seeker));
        when(jobRepository.findById(100L)).thenReturn(Optional.of(job));
        when(applicationRepository.existsByJobIdAndJobSeekerId(100L, 5L)).thenReturn(true);

        assertThrows(DuplicateResourceException.class, () -> 
            applicationService.applyForJob("seeker@example.com", new ApplicationRequest(100L, "Cover letter"))
        );
    }

    @Test
    void testUpdateApplicationStatus_Success() {
        User recruiterUser = new User(2L, "admin@example.com", "pass", "Admin", "+123", Role.ROLE_ADMIN, true);
        when(userRepository.findByEmail("admin@example.com")).thenReturn(Optional.of(recruiterUser));
        when(applicationRepository.findById(50L)).thenReturn(Optional.of(application));
        when(applicationJdbcDao.updateApplicationStatusWithJdbc(50L, ApplicationStatus.SHORTLISTED)).thenReturn(true);

        ApplicationResponse response = applicationService.updateApplicationStatus("admin@example.com", 50L, new ApplicationStatusUpdateRequest(ApplicationStatus.SHORTLISTED));

        assertNotNull(response);
        verify(applicationJdbcDao, times(1)).updateApplicationStatusWithJdbc(50L, ApplicationStatus.SHORTLISTED);
    }
}
