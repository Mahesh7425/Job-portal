# JOB PORTAL SYSTEM - MCA Full-Stack Project

A complete, production-grade **Job Portal System** built with **Java 17+**, **Spring Boot 3**, **Spring Security + JWT**, **Spring Data JPA**, **Native Spring JDBC / DAO**, **MySQL 8.0**, and a modern responsive **HTML5 / CSS3 / Vanilla JavaScript** frontend.

---

## 🌟 Key Features

### 1. Multi-Role Authorization & Security
- **Job Seeker**: Create & manage profile, upload/view resume, add skills/education/experience, search & filter jobs, apply, track candidate status pipelines (`APPLIED`, `UNDER_REVIEW`, `SHORTLISTED`, `SELECTED`, `REJECTED`), and bookmark jobs.
- **Recruiter / Company**: Create company profile, upload company logo, post/edit/delete/toggle job listings, view applicants with resume links, and update application status.
- **System Admin**: Complete dashboard statistics, user management (enable/disable/delete), company & job management, manual "Sync Now" external job trigger, and sync logs timeline.
- **Stateless JWT Security**: Passwords hashed with BCrypt (strength 10), role-based endpoint access control (`ROLE_JOB_SEEKER`, `ROLE_RECRUITER`, `ROLE_ADMIN`).

### 2. Dual Data Access Strategy (JPA + JDBC)
- **Spring Data JPA**: For object-relational mapping and standard repository operations.
- **Native Spring JDBC (`JdbcTemplate` / DAO)**: Used explicitly for multi-faceted search parameter binding (`PreparedStatement`), status updates, and administrative reporting to fulfill **MCA JDBC academic evaluation requirements**.

### 3. External Job Aggregation Engine
- **Strategy Pattern (`ExternalJobProvider`)**:
  - `RemoteOkJobProviderImpl`: Connects to authorized public REST API (`https://remoteok.com/api`).
  - `MockExternalJobProviderImpl`: Configurable mock feed supplying realistic external software jobs for reliable offline academic demonstration.
- **De-Duplication**: Prevents duplicate listings using composite index `(external_id, source_name)`.
- **Spring `@Scheduled` Sync**: Background cron runner executing every 30 minutes (configurable via `application.yml`).
- **Sync Logging**: Logs every execution timestamp, status, duration, added count, and updated count into `external_sync_logs` MySQL table.

---

## 🛠️ Technology Stack

- **Backend**: Java 17+, Spring Boot 3.3.3, Spring MVC, Spring Security, Spring Data JPA, Spring JDBC (`JdbcTemplate`), JJWT 0.12.6, Maven
- **Database**: MySQL 8.0+
- **Frontend**: HTML5, CSS3 (Modern Glassmorphism Design System), Vanilla JavaScript (Fetch API / AJAX)

---

## ⚙️ Prerequisites & Installation

### 1. Prerequisites
- **JDK 17+** (JDK 23 supported)
- **Apache Maven 3.8+**
- **MySQL Server 8.0+** running on `localhost:3306`

### 2. Database Setup
1. Connect to MySQL CLI:
   ```bash
   mysql -u root -p
   ```
2. Run the initialization script:
   ```sql
   source database.sql;
   ```
   *This creates `job_portal_db`, 13 normalized tables, foreign keys, indexes, and initial test seed data.*

### 3. Application Configuration
Check `src/main/resources/application.yml` for database settings. Credentials can be passed dynamically via environment variables:
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/job_portal_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
    username: ${DB_USERNAME:root}
    password: ${DB_PASSWORD:}
```

### 4. Build and Run Application
Run using Maven:
```bash
mvn clean package -DskipTests
java -jar target/job-portal-system-1.0.0.jar
```
Or start directly via Spring Boot Maven plugin:
```bash
mvn spring-boot:run
```

Access the application in your browser at:
👉 `http://localhost:8080`

---

## 🔑 Default Seed Credentials for Testing

| Role | Email | Password |
|---|---|---|
| **System Admin** | `admin@jobportal.com` | `Admin@123` |
| **Recruiter** | `recruiter@techcorp.com` | `Recruiter@123` |
| **Job Seeker** | `seeker@gmail.com` | `Seeker@123` |

*(Quick demo login buttons are provided on `login.html` for instant testing)*

---

## 📌 REST API Endpoint Matrix

| Method | Endpoint | Authority | Description |
|---|---|---|---|
| `POST` | `/api/auth/register` | Public | Register new Job Seeker or Recruiter |
| `POST` | `/api/auth/login` | Public | Authenticate user & return JWT token |
| `GET` | `/api/auth/me` | Authenticated | Get current logged in user details |
| `GET` | `/api/jobs` | Public | Multi-filter dynamic search (paginated) |
| `GET` | `/api/jobs/{id}` | Public | Get position details |
| `POST` | `/api/jobs` | Recruiter/Admin | Post new job listing |
| `PUT` | `/api/jobs/{id}` | Recruiter/Admin | Update job listing |
| `DELETE` | `/api/jobs/{id}` | Recruiter/Admin | Delete job listing |
| `POST` | `/api/applications` | Seeker/Admin | Apply for job with cover letter |
| `GET` | `/api/applications/my-applications` | Seeker/Admin | View applied jobs & status history |
| `PUT` | `/api/applications/{id}/status` | Recruiter/Admin | Update applicant pipeline status |
| `POST` | `/api/admin/sync-now` | Admin | Manually trigger external job sync |
| `GET` | `/api/admin/dashboard/stats` | Admin | Get system-wide metric counters |

---

## 📄 Documentation Files
- [PROJECT_DOCUMENTATION.md](file:///e:/JAVA_Project/PROJECT_DOCUMENTATION.md): Comprehensive MCA Project Report & Architecture Specifications.
- [database.sql](file:///e:/JAVA_Project/database.sql): Complete MySQL DDL & Seed Script.
