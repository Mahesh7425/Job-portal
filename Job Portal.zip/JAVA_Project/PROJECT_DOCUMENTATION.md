# PROJECT DOCUMENTATION - JOB PORTAL SYSTEM
**Degree**: Master of Computer Applications (MCA)  
**Project Title**: Full-Stack Job Portal System with External Job Aggregation  
**Technology**: Java 17+, Spring Boot 3, Spring Security, JPA, JDBC, MySQL, HTML5/CSS3/JavaScript  

---

## 1. Problem Statement & Objectives

### Problem Statement
Traditional job posting portals often operate in isolated silos, requiring job seekers to navigate multiple websites to discover open technical opportunities. Furthermore, enterprise platforms require robust role-based security, applicant tracking workflows, direct database access performance optimizations, and reliable integration with external job feeds.

### Project Objectives
1. **Full-Stack Architecture**: Build a complete end-to-end Job Portal application without relying on third-party frameworks like React/Angular on the client side.
2. **Role-Based Access Control**: Implement secure authentication and distinct dashboards for Job Seekers, Recruiters, and System Administrators.
3. **Dual Data Access Layer**: Demonstrate mastery of both **Spring Data JPA** (ORM) and **Native Spring JDBC (`JdbcTemplate` / custom DAOs)** with `PreparedStatement` parameter binding for academic evaluation.
4. **External Job Aggregation**: Integrate public REST job APIs via a Strategy Pattern architecture supporting both live feeds and configurable mock providers for offline testing.
5. **Scheduled Synchronization**: Implement background Spring `@Scheduled` tasks to execute de-duplication, update existing listings, and log execution metrics to MySQL.

---

## 2. System Architecture & ER Diagram Description

### Architecture Layers
- **Client Layer**: HTML5, CSS3 Glassmorphism UI, Vanilla JavaScript Fetch API client (`api.js`) managing JWT tokens in `localStorage`.
- **Controller Layer**: REST Controllers handling HTTP requests and returning JSON responses with proper HTTP status codes (200, 201, 400, 401, 403, 404, 409, 500).
- **Service Layer**: Core business logic, password encryption (BCrypt), resume/logo storage, candidate pipeline status management, and external job aggregation.
- **Data Access Layer**: 
  - Spring Data JPA Repositories for entity persistence.
  - Custom JDBC DAOs (`UserJdbcDaoImpl`, `JobJdbcDaoImpl`, `ApplicationJdbcDaoImpl`, `CompanyJdbcDaoImpl`) for multi-faceted search query generation and batch execution.
- **Database Layer**: Normalized MySQL 8.0 relational database with 13 tables, foreign key cascading, and composite indexes.

### Normalized Entity Relationships
- `USERS` (1) ── (1) `JOB_SEEKERS`
- `USERS` (1) ── (1) `RECRUITERS`
- `COMPANIES` (1) ── (N) `RECRUITERS`
- `COMPANIES` (1) ── (N) `JOBS`
- `RECRUITERS` (1) ── (N) `JOBS`
- `JOB_SEEKERS` (N) ── (M) `SKILLS` (via `JOB_SEEKER_SKILLS`)
- `JOBS` (N) ── (M) `SKILLS` (via `JOB_SKILLS`)
- `JOB_SEEKERS` (1) ── (N) `EDUCATION`
- `JOB_SEEKERS` (1) ── (N) `EXPERIENCE`
- `JOB_SEEKERS` (1) ── (N) `APPLICATIONS` ── (1) `JOBS`
- `JOB_SEEKERS` (1) ── (N) `SAVED_JOBS` ── (1) `JOBS`

---

## 3. Database Schema Specifications

```
1. users (id, email, password, full_name, phone, role, is_active, created_at, updated_at)
2. companies (id, name, description, website, location, logo_url, industry, created_at)
3. recruiters (id, user_id, company_id, designation)
4. job_seekers (id, user_id, title, bio, resume_url, experience_years, expected_salary, location)
5. skills (id, name)
6. job_seeker_skills (job_seeker_id, skill_id)
7. education (id, job_seeker_id, degree, institution, field_of_study, start_year, end_year, grade)
8. experience (id, job_seeker_id, company_name, job_title, start_date, end_date, is_current, description)
9. jobs (id, recruiter_id, company_id, title, description, location, salary_min, salary_max, experience_required, employment_type, is_active, source, source_name, external_url, external_id, company_name_ext, posted_at)
10. job_skills (job_id, skill_id)
11. applications (id, job_id, job_seeker_id, status, cover_letter, applied_at, updated_at)
12. saved_jobs (id, job_seeker_id, job_id, saved_at)
13. external_sync_logs (id, sync_time, provider_name, status, jobs_added, jobs_updated, execution_duration_ms, error_message)
```

---

## 4. Native JDBC Implementation (MCA Requirement)

To satisfy the explicit academic JDBC requirement, custom DAOs execute native SQL using `JdbcTemplate` and `PreparedStatement`:
- **`UserJdbcDaoImpl`**: Verifies login credentials and counts total users directly via SQL `PreparedStatement` queries.
- **`JobJdbcDaoImpl`**: Dynamically constructs SQL `WHERE` clauses for multi-filtered search based on keywords, titles, locations, salary, experience, and source, returning paginated results (`LIMIT / OFFSET`).
- **`ApplicationJdbcDaoImpl`**: Performs direct SQL status updates (`UPDATE applications SET status = ?, updated_at = NOW() WHERE id = ?`).
- **`CompanyJdbcDaoImpl`**: Direct JDBC queries for company listings and statistics.

---

## 5. External Job Aggregation & Scheduler

- **Strategy Interface (`ExternalJobProvider`)**: Standardizes external job retrieval across multiple providers.
- **Implementations**:
  - `RemoteOkJobProviderImpl`: Calls RemoteOK API feed.
  - `MockExternalJobProviderImpl`: Generates mock software developer jobs for reliable offline demonstration.
- **De-Duplication**: Checks composite key `(external_id, source_name)` in MySQL to update modified listings or insert new entries.
- **Spring `@Scheduled` Sync**: Automatic background execution every 30 minutes, recording execution metrics in `external_sync_logs`.

---

## 6. Testing & Quality Assurance

Automated unit and integration test suites developed using **JUnit 5** and **Mockito**:
- `AuthServiceTest`: Validates registration, duplicate email check, and JWT login.
- `JobServiceTest`: Validates job creation, retrieval, and JDBC DAO search execution.
- `ApplicationServiceTest`: Validates job applications, duplicate prevention, and status updates.
- `ExternalJobAggregationServiceTest`: Validates provider Strategy pattern execution, de-duplication logic, and log insertion.

---

## 7. Future Scope & Enhancements

1. **Email Notifications**: Integration with JavaMailSender to notify candidates on status updates (`SHORTLISTED`, `SELECTED`).
2. **AI Resume Screening**: Automated matching score between job seeker skills and posted job skill requirements.
3. **OAuth2 Social Logins**: Single Sign-On (SSO) via Google and LinkedIn OAuth2 providers.
