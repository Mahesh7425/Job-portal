-- ===================================================
-- JOB PORTAL SYSTEM - MCA FULL-STACK PROJECT
-- Database Initialization & Schema Creation Script
-- Database: MySQL 8.0+
-- ===================================================

CREATE DATABASE IF NOT EXISTS `job_portal_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `job_portal_db`;

-- Disable foreign key checks for clean creation
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `external_sync_logs`;
DROP TABLE IF EXISTS `saved_jobs`;
DROP TABLE IF EXISTS `applications`;
DROP TABLE IF EXISTS `job_skills`;
DROP TABLE IF EXISTS `jobs`;
DROP TABLE IF EXISTS `experience`;
DROP TABLE IF EXISTS `education`;
DROP TABLE IF EXISTS `job_seeker_skills`;
DROP TABLE IF EXISTS `skills`;
DROP TABLE IF EXISTS `job_seekers`;
DROP TABLE IF EXISTS `recruiters`;
DROP TABLE IF EXISTS `companies`;
DROP TABLE IF EXISTS `users`;

SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS TABLE
CREATE TABLE `users` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `role` ENUM('ROLE_JOB_SEEKER', 'ROLE_RECRUITER', 'ROLE_ADMIN') NOT NULL,
  `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. COMPANIES TABLE
CREATE TABLE `companies` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `website` VARCHAR(255) DEFAULT NULL,
  `location` VARCHAR(100) DEFAULT NULL,
  `logo_url` VARCHAR(255) DEFAULT NULL,
  `industry` VARCHAR(100) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_companies_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. RECRUITERS TABLE
CREATE TABLE `recruiters` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL UNIQUE,
  `company_id` BIGINT DEFAULT NULL,
  `designation` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_recruiters_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_recruiters_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. JOB SEEKERS TABLE
CREATE TABLE `job_seekers` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL UNIQUE,
  `title` VARCHAR(100) DEFAULT NULL,
  `bio` TEXT DEFAULT NULL,
  `resume_url` VARCHAR(255) DEFAULT NULL,
  `experience_years` INT DEFAULT 0,
  `expected_salary` DECIMAL(12,2) DEFAULT 0.00,
  `location` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_seekers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. SKILLS TABLE
CREATE TABLE `skills` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  PRIMARY KEY (`id`),
  INDEX `idx_skills_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. JOB SEEKER SKILLS TABLE (Many-to-Many)
CREATE TABLE `job_seeker_skills` (
  `job_seeker_id` BIGINT NOT NULL,
  `skill_id` BIGINT NOT NULL,
  PRIMARY KEY (`job_seeker_id`, `skill_id`),
  CONSTRAINT `fk_jss_seeker` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jss_skill` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. EDUCATION TABLE
CREATE TABLE `education` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `job_seeker_id` BIGINT NOT NULL,
  `degree` VARCHAR(100) NOT NULL,
  `institution` VARCHAR(150) NOT NULL,
  `field_of_study` VARCHAR(100) DEFAULT NULL,
  `start_year` INT DEFAULT NULL,
  `end_year` INT DEFAULT NULL,
  `grade` VARCHAR(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_edu_seeker` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. EXPERIENCE TABLE
CREATE TABLE `experience` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `job_seeker_id` BIGINT NOT NULL,
  `company_name` VARCHAR(150) NOT NULL,
  `job_title` VARCHAR(100) NOT NULL,
  `start_date` DATE DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `is_current` BOOLEAN DEFAULT FALSE,
  `description` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_exp_seeker` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. JOBS TABLE
CREATE TABLE `jobs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `recruiter_id` BIGINT DEFAULT NULL,
  `company_id` BIGINT DEFAULT NULL,
  `title` VARCHAR(150) NOT NULL,
  `description` TEXT NOT NULL,
  `location` VARCHAR(100) NOT NULL,
  `salary_min` DECIMAL(12,2) DEFAULT NULL,
  `salary_max` DECIMAL(12,2) DEFAULT NULL,
  `experience_required` INT DEFAULT 0,
  `employment_type` ENUM('FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERNSHIP', 'REMOTE') NOT NULL DEFAULT 'FULL_TIME',
  `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
  `source` ENUM('DIRECT', 'EXTERNAL') NOT NULL DEFAULT 'DIRECT',
  `source_name` VARCHAR(100) DEFAULT 'Direct Posting',
  `external_url` VARCHAR(500) DEFAULT NULL,
  `external_id` VARCHAR(100) DEFAULT NULL,
  `company_name_ext` VARCHAR(150) DEFAULT NULL,
  `posted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_external_job` (`external_id`, `source_name`),
  CONSTRAINT `fk_jobs_recruiter` FOREIGN KEY (`recruiter_id`) REFERENCES `recruiters` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jobs_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  INDEX `idx_jobs_title` (`title`),
  INDEX `idx_jobs_location` (`location`),
  INDEX `idx_jobs_active` (`is_active`),
  INDEX `idx_jobs_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. JOB SKILLS TABLE (Many-to-Many)
CREATE TABLE `job_skills` (
  `job_id` BIGINT NOT NULL,
  `skill_id` BIGINT NOT NULL,
  PRIMARY KEY (`job_id`, `skill_id`),
  CONSTRAINT `fk_js_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_js_skill` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. APPLICATIONS TABLE
CREATE TABLE `applications` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `job_id` BIGINT NOT NULL,
  `job_seeker_id` BIGINT NOT NULL,
  `status` ENUM('APPLIED', 'UNDER_REVIEW', 'SHORTLISTED', 'REJECTED', 'SELECTED') NOT NULL DEFAULT 'APPLIED',
  `cover_letter` TEXT DEFAULT NULL,
  `applied_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_job_seeker_application` (`job_id`, `job_seeker_id`),
  CONSTRAINT `fk_apps_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_apps_seeker` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`id`) ON DELETE CASCADE,
  INDEX `idx_apps_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. SAVED JOBS TABLE
CREATE TABLE `saved_jobs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `job_seeker_id` BIGINT NOT NULL,
  `job_id` BIGINT NOT NULL,
  `saved_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_seeker_saved_job` (`job_seeker_id`, `job_id`),
  CONSTRAINT `fk_saved_seeker` FOREIGN KEY (`job_seeker_id`) REFERENCES `job_seekers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_saved_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. EXTERNAL SYNC LOGS TABLE
CREATE TABLE `external_sync_logs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `sync_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `provider_name` VARCHAR(100) NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  `jobs_added` INT DEFAULT 0,
  `jobs_updated` INT DEFAULT 0,
  `execution_duration_ms` BIGINT DEFAULT 0,
  `error_message` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===================================================
-- SAMPLE SEED DATA FOR TESTING
-- Default Passwords:
-- admin@jobportal.com -> Admin@123
-- recruiter@techcorp.com -> Recruiter@123
-- seeker@gmail.com -> Seeker@123
-- (BCrypt hashes generated with strength 10)
-- ===================================================

INSERT INTO `users` (`id`, `email`, `password`, `full_name`, `phone`, `role`, `is_active`) VALUES
(1, 'admin@jobportal.com', '$2a$10$7Z8H1yQzF3kH4L5M6N7O8e9P0Q1R2S3T4U5V6W7X8Y9Z0a1b2c3d4', 'System Administrator', '+19876543210', 'ROLE_ADMIN', TRUE),
(2, 'recruiter@techcorp.com', '$2a$10$7Z8H1yQzF3kH4L5M6N7O8e9P0Q1R2S3T4U5V6W7X8Y9Z0a1b2c3d4', 'Sarah Jenkins', '+15551234567', 'ROLE_RECRUITER', TRUE),
(3, 'seeker@gmail.com', '$2a$10$7Z8H1yQzF3kH4L5M6N7O8e9P0Q1R2S3T4U5V6W7X8Y9Z0a1b2c3d4', 'Alex Rivera', '+15559876543', 'ROLE_JOB_SEEKER', TRUE);

INSERT INTO `companies` (`id`, `name`, `description`, `website`, `location`, `logo_url`, `industry`) VALUES
(1, 'TechCorp Solutions', 'Leading enterprise cloud and Java software solutions provider.', 'https://techcorp.example.com', 'San Francisco, CA', '/uploads/logos/techcorp.png', 'Software & Technology'),
(2, 'CloudScale Systems', 'Cutting-edge microservices and distributed computing infrastructure.', 'https://cloudscale.example.com', 'Austin, TX', '/uploads/logos/cloudscale.png', 'Cloud Computing');

INSERT INTO `recruiters` (`id`, `user_id`, `company_id`, `designation`) VALUES
(1, 2, 1, 'Senior Technical Talent Acquisition');

INSERT INTO `job_seekers` (`id`, `user_id`, `title`, `bio`, `experience_years`, `expected_salary`, `location`) VALUES
(1, 3, 'Full Stack Java Engineer', 'Passionate Software Engineer with hands-on experience in Java, Spring Boot, MySQL, and Web Development.', 3, 95000.00, 'Seattle, WA');

INSERT INTO `skills` (`id`, `name`) VALUES
(1, 'Java'), (2, 'Spring Boot'), (3, 'MySQL'), (4, 'JavaScript'), (5, 'HTML5'),
(6, 'CSS3'), (7, 'REST API'), (8, 'Docker'), (9, 'Microservices'), (10, 'React');

INSERT INTO `job_seeker_skills` (`job_seeker_id`, `skill_id`) VALUES
(1, 1), (1, 2), (1, 3), (1, 4), (1, 7);

INSERT INTO `education` (`id`, `job_seeker_id`, `degree`, `institution`, `field_of_study`, `start_year`, `end_year`, `grade`) VALUES
(1, 1, 'Master of Computer Applications (MCA)', 'University of Technology', 'Computer Science', 2021, 2023, '3.9 GPA');

INSERT INTO `experience` (`id`, `job_seeker_id`, `company_name`, `job_title`, `start_date`, `end_date`, `is_current`, `description`) VALUES
(1, 1, 'WebTech Innovations', 'Associate Software Engineer', '2023-06-01', NULL, TRUE, 'Developing Java Spring Boot REST APIs and relational database optimizations.');

INSERT INTO `jobs` (`id`, `recruiter_id`, `company_id`, `title`, `description`, `location`, `salary_min`, `salary_max`, `experience_required`, `employment_type`, `is_active`, `source`, `source_name`, `posted_at`) VALUES
(1, 1, 1, 'Senior Java Spring Developer', 'We are seeking an experienced Java Developer to lead our microservices backend architecture. Requires deep knowledge of Spring Boot, JPA, and MySQL.', 'San Francisco, CA', 110000.00, 140000.00, 4, 'FULL_TIME', TRUE, 'DIRECT', 'Direct Posting', NOW()),
(2, 1, 1, 'Full Stack Web Developer', 'Build intuitive modern user interfaces using HTML, CSS, JavaScript, and connect them with Spring Boot REST services.', 'Remote', 85000.00, 115000.00, 2, 'REMOTE', TRUE, 'DIRECT', 'Direct Posting', NOW());

INSERT INTO `job_skills` (`job_id`, `skill_id`) VALUES
(1, 1), (1, 2), (1, 3), (1, 7), (1, 9),
(2, 1), (2, 4), (2, 5), (2, 6), (2, 7);

INSERT INTO `applications` (`id`, `job_id`, `job_seeker_id`, `status`, `cover_letter`, `applied_at`) VALUES
(1, 1, 1, 'UNDER_REVIEW', 'I am very excited to apply for the Senior Java Spring Developer role. My 3 years of hands-on Spring Boot experience aligns well with your team.', NOW());

INSERT INTO `external_sync_logs` (`id`, `provider_name`, `status`, `jobs_added`, `jobs_updated`, `execution_duration_ms`, `error_message`) VALUES
(1, 'Mock External Feed', 'SUCCESS', 5, 0, 120, NULL);

-- Reset FK checks
SET FOREIGN_KEY_CHECKS = 1;
